package ventanas;

import java.util.Random;

import entidades.NiceLander;

public class Panel {

	private EstadoPanel estado;

	private Random rand = new Random();
	private NiceLander nicelander;

	public NiceLander getNicelander() {
		return nicelander;
	}

	public void setNicelander(NiceLander nicelander) {
		this.nicelander = nicelander;
	}

	/*
	 * CREA UN PANEL CON LA PROBABILIDAD DE QUE ESTÉ ROTO O SANO
	 */
	public Panel(double Proba) {
		double num = rand.nextDouble();
		double div = num / Proba;
		if ((0 < div) && (div < 0.4))
			this.setEstado(EstadoPanel.SANO);
		else if ((0.4 < div) && (div < 0.8))
			this.setEstado(EstadoPanel.SEMI_ROTO);
		else
			this.setEstado(EstadoPanel.ROTO);
	}

	/**
	 * Se utiliza para crear los paneles de las ventanas "DosHojas" que estan siempre sanos y no se rompen
	 * @param tiene
	 */
	public Panel(boolean tiene) {
		this.setEstado(EstadoPanel.SANO);
		if(tiene)
			this.setNicelander(new NiceLander());
	}

	/*
	 * CREA UN PANEL CON LA PROBABILIDAD DE QUE EST� ROTO SEMI ROTO, SANO Y SI TIENE
	 * O NO NICELANDER
	 */
	public Panel(double Proba, boolean nice) {
		double num = rand.nextDouble();
		double div = num / Proba;
		if ((0 < div) && (div < 0.4))
			this.setEstado(EstadoPanel.SANO);
		else if ((0.4 < div) && (div < 0.8))
			this.setEstado(EstadoPanel.SEMI_ROTO);
		else
			this.setEstado(EstadoPanel.ROTO);
		if (nice)
			this.setNicelander(new NiceLander());
	}

	/*
	 * RETORNA EL ESTADO ACTUAL DEL PANEL
	 */
	public EstadoPanel getEstado() {
		return estado;
	}

	/*
	 * CONFIGURA EL ESTADO DEL PANEL
	 */
	public void setEstado(EstadoPanel estado) {
		this.estado = estado;
	}

	/*
	 * REPARA EL PANEL
	 */
	public void repararPanel() {
		if (estado.equals(EstadoPanel.ROTO)) {
			setEstado(EstadoPanel.SEMI_ROTO);
		} else {
			if (estado.equals(EstadoPanel.SEMI_ROTO)) {
				setEstado(EstadoPanel.SANO);
			}
		}
	}

}
