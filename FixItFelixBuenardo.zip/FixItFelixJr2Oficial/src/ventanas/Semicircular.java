package ventanas;

public class Semicircular extends Ventana {

	/*
	 * CONSTRUCTOR QUE NO CONFIGURA PANELES
	 */
	public Semicircular() {
		super();
		this.tipo = TipoVentana.SEMICIRCULAR;
	}

	/*
	 * CONSTRUCTOR QUE CONFIGURA PANELES
	 */
	public Semicircular(double proba) {
		super();
		this.tipo = TipoVentana.SEMICIRCULAR;
		for (int i = 0; i < 8; i++)
			this.paneles.add(new Panel(proba));
	}

}
