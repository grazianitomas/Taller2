package ventanas;

import java.util.ArrayList;

import entidades.Maceta;
import entidades.Moldura;
import individuos.DireccionFelix;

public abstract class Ventana {

	private Maceta maceta;
	private Moldura moldura;
	private double probabilidad;
	protected ArrayList<Panel> paneles;
	public boolean pastel;
	protected TipoVentana tipo;
	protected OpenClose estado;

	public OpenClose getEstado() {
		return estado;
	}

	public void setEstado(OpenClose estado) {
		this.estado = estado;
	}

	public TipoVentana getTipo() {
		return tipo;
	}

	public void setTipo(TipoVentana tipo) {
		this.tipo = tipo;
	}

	public boolean isPastel() {
		return pastel;
	}

	public void setPastel(boolean pastel) {
		this.pastel = pastel;
	}

	/**
	 * CONSTRUCTOR VAC�O
	 */
	public Ventana() {
		paneles = new ArrayList<Panel>();
	}

	/**
	 * CONSTRUCTOR QUE SOLO INSTANCIA MACETAS Y TECHO
	 * 
	 * @param maceta
	 * @param techo
	 */
	public Ventana(Maceta maceta, Moldura moldura) {
		this.paneles = new ArrayList<Panel>();
		this.maceta = maceta;
		this.moldura = moldura;
	}

	/**
	 * CONSTRUCTOR QUE INSTANCIA TAMBIÉN LOS PANELES
	 * 
	 * @param maceta
	 * @param techo
	 * @param paneles panel a configurar
	 */
	public Ventana(Maceta maceta, Moldura moldura, ArrayList<Panel> paneles) {

		this.paneles = new ArrayList<Panel>();
		this.maceta = maceta;
		this.moldura = moldura;
		this.paneles = paneles;
	}

	/**
	 * RETORNA VERDADERO SI HAY MACETA EN LA VENTANA
	 * 
	 * @return verdadero o falso
	 */
	public Maceta getMaceta() {
		return maceta;
	}

	/**
	 * CONFIGURA UNA MACETA EN LA VENTANA
	 * 
	 * @param maceta
	 */
	public void setMaceta(Maceta maceta) {
		this.maceta = maceta;
	}

	/**
	 * RETORNA VERDADERO SI HAY TECHO EN LA VENTANA
	 * 
	 * @return verdadero o falso
	 */
	public Moldura getMoldura() {
		return this.moldura;
	}

	/**
	 * CONFIGURA UN TECHO O MOLDURA EN LA VENTANA
	 * 
	 * @param techo
	 */
	public void setMoldura(Moldura moldura) {
		this.moldura = moldura;
	}

	/**
	 * REPARA LA VENTANA ACTUAL
	 * 
	 * @return retorna 100 si se reparó, o 0 si ya estaba reparada
	 */
	public int repararVentana() {
		if (!this.getSana()) {
			boolean roto = true;
			int i = 0;
			int size = paneles.size();
			while ((roto) && (i < size)) {
				if (!paneles.get(i).getEstado().equals(EstadoPanel.SANO)) {
					paneles.get(i).repararPanel();
					roto = false;
				}
				i++;
			}
			if (roto)
				return 100;
		}
		return 0;
	}

	/**
	 * RETORNA VERDADERO SI LA VENTANA ACTUAL SE ENCUENTRA COMPLETAMENTE SANA
	 * 
	 * @return verdadero o falso
	 */
	public boolean getSana() {
		boolean noRoto = true;
		int i = 0;
		int size = paneles.size();
		while ((noRoto) && (i < size)) {
			if (paneles.get(i).getEstado().equals(EstadoPanel.ROTO)
					|| paneles.get(i).getEstado().equals(EstadoPanel.SEMI_ROTO)) {
				noRoto = false;
			}
			i++;
		}
		return noRoto;
	}

	/**
	 * Calcula la cantidad de paneles rotos, semirotos y sanos
	 * 
	 * @return Retorna la cantidad de c/panel, en el orden dicho antes.
	 */
	public int getCantRotos() {
		int cant = 0;
		int size = paneles.size();
		for (int i = 0; i < size; i++)
			switch (paneles.get(i).getEstado()) {
			case ROTO:
				cant += 1;
				break;
			case SEMI_ROTO:
				cant += 1;
				break;
			default:
				break;
			}
		return cant;
	}

	/**
	 * CONFIGURA LA PROBABILIDAD DE QUE LOS PANELES ESTEN ROTOS
	 * 
	 * @param proba probabilidad de que los planeles esten rotos
	 */
	public void setProba(double proba) {
		this.probabilidad = proba;
	}

	/**
	 * RETORNA LA PROBABILIDAD DE QUE LOS PANELES ESTEN ROTOS
	 * 
	 * @return double
	 */
	public double getProba() {
		return this.probabilidad;
	}

	/**
	 * Retorna la ventana actual
	 * 
	 * @return
	 */
	public Ventana getVentana() {
		return this;
	}

	/**
	 * Verifica si Felix puede moverse en direcciones de arriba o abajo
	 * 
	 * @param direc direccion a la que se solicita moverse
	 * @return verdadero o falso
	 */
	public boolean puedeMoverse(DireccionFelix direc) {
		if (direc.equals(DireccionFelix.ARRIBA)) {
			if (!(this.getMoldura() == null)) {
				return true;
			} else
				return false;
		} else {
			if (!(this.getMaceta() == null)) {
				return true;
			} else
				return false;

		}
	}

	public ArrayList<Panel> getPaneles() {
		return paneles;
	}

	public void setPaneles(ArrayList<Panel> paneles) {
		this.paneles = paneles;
	}

}
