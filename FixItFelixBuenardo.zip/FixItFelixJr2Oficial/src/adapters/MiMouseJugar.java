package adapters;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import controladores.Juego;
import vistas.FrameMenu;

public class MiMouseJugar extends MouseAdapter {

	public MiMouseJugar() {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		try {
			FrameMenu.instancia().setCard("Juego");
			Juego.getGame().darMarcha();
		} catch (Exception d) {
			d.printStackTrace();
		}
		super.mouseClicked(e);
	}

}
