package niceland;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import ventanas.*;

public class Seccion {
	private static EstadoSeccion seccionActual;
	private ArrayList<ArrayList<Ventana>> ventanas;
	Random rand = new Random();

	/**
	 * CONSTRUYE LAS SECCION CORRESPONDIENTE CON EL PAR�mETRO "K" CON LA
	 * CORRESPONDIENTE PROBABILIDAD DE PANELES ROTOS, PASADOS CON "PROBA"
	 * 
	 * @param proba
	 * @param k
	 */
	public Seccion(EstadoSeccion ES, double proba) {
		this.ventanas = new ArrayList<ArrayList<Ventana>>();
		if (ES.equals(EstadoSeccion.SECCION_INFERIOR)) {
			seccionInferior(proba);
			this.setSeccionActual(EstadoSeccion.SECCION_INFERIOR);
			return;
		} else if (ES.equals(EstadoSeccion.SECCION_MEDIA)) {
			seccionMedia(proba);
			this.pasarSeccion();
			return;
		} else {
			if (ES.equals(EstadoSeccion.SECCION_SUPERIOR))
				seccionMedia(proba);// Es la misma sección media pero con mas probabilidad
		}
	}

	/**
	 * Crea una sección media
	 * 
	 * @param proba
	 */
	private void seccionMedia(double proba) {
		Ventana[] aux = new Ventana[5];
		int tam = aux.length;
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.5)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}
		ArrayList<Ventana> fila1 = new ArrayList<Ventana>(Arrays.asList(aux[0], aux[1], aux[2], aux[3], aux[4]));
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.3)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}
		ArrayList<Ventana> fila2 = new ArrayList<Ventana>(Arrays.asList(aux[0], aux[1], aux[2], aux[3], aux[4]));
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.1)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}
		ArrayList<Ventana> fila3 = new ArrayList<Ventana>(Arrays.asList(aux[0], aux[1], aux[2], aux[3], aux[4]));
		ventanas.add(fila1);
		ventanas.add(fila2);
		ventanas.add(fila3);
	}

	/**
	 * Crea una secci�n inferior
	 * 
	 * @param proba
	 */
	private void seccionInferior(double proba) {
		Ventana[] aux = new Ventana[5];
		int tam = aux.length;
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.5)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}

		ArrayList<Ventana> fila1 = new ArrayList<Ventana>(Arrays.asList(aux[0], aux[1], aux[2], aux[3], aux[4]));
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.3)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}

		ArrayList<Ventana> fila2 = new ArrayList<Ventana>(
				Arrays.asList(aux[0], aux[1], new Semicircular(proba), aux[3], aux[4]));
		for (int i = 0; i < tam; i++) {
			if (rand.nextInt(4) / (proba / 2) > 0.1)
				aux[i] = new Comun(proba);
			else
				aux[i] = new DosHojas(proba);

		}
		ArrayList<Ventana> fila3 = new ArrayList<Ventana>(
				Arrays.asList(aux[0], aux[2], new Puerta(proba), aux[3], aux[4]));
		ventanas.add(fila1);
		ventanas.add(fila2);
		ventanas.add(fila3);
	}

	/**
	 * RETORNA LA SECCION ACTUAL EN TIPO ENUMERATIVO
	 * 
	 * @return
	 */
	public EstadoSeccion getSeccionActual() {
		return seccionActual;
	}

	public int getSeccionNum() {
		return getSeccionActual().getSeccionEnNumero();
	}

	/**
	 * CONFIGURA LA SECCION ACTUAL CON LA PASADA POR PAR�METRO
	 * 
	 * @param actual
	 */
	public void setSeccionActual(EstadoSeccion actual) {
		seccionActual = actual;
	}

	/**
	 * MODULA EL PASAJE DE SECCION
	 */
	public void pasarSeccion() {
		seccionActual.pasarSeccion();
	}

	/**
	 * RETORNA LA VENTANA EN LAS POSICIONES DADAS
	 * 
	 * @param x posicion en x a buscar
	 * @param y posicion en y a buscar
	 * @return Retorna la matriz en la posicion pasada por parametro
	 */
	public Ventana getVentana(int x, int y) {
		return ventanas.get(x).get(y);
	}

	/**
	 * RETORNA LA MATRIZ COMPLETA DE VENTANAS
	 * 
	 * @return
	 */
	public ArrayList<ArrayList<Ventana>> getMatrizVentanas() {
		return ventanas;
	}

}
