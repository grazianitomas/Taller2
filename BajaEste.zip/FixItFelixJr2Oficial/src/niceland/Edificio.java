package niceland;

import java.util.ArrayList;

import modelo.Juego;

public class Edificio {
	private Seccion secciones;
	private static double probabilidadSeccion = 0.0;
	private ArrayList<Seccion> seccionVector = new ArrayList<Seccion>();
	private EstadoSeccion seccionActual;

	public static double getProbabilidadSeccion() {
		return probabilidadSeccion;
	}

	public static void setProbabilidadSeccion(double probabilidadSeccion) {
		Edificio.probabilidadSeccion = probabilidadSeccion;
	}

	public ArrayList<Seccion> getSeccionVector() {
		return seccionVector;
	}

	public void setSeccionVector(ArrayList<Seccion> seccionVector) {
		this.seccionVector = seccionVector;
	}

	/**
	 * Retorna una sección
	 * 
	 * @param i
	 * @return
	 */
	public Seccion getSeccion() {
		return this.secciones;
	}

	/**
	 * Realiza el pasaje de sección
	 */
	public void pasarDeSeccion() {
		int seccion = Juego.getGame().getNiceland().getSeccionActual().getSeccionEnNumero();
		secciones = seccionVector.get(seccion);
	}

	/**
	 * Settea la seccion por la pasada por parámetro
	 * 
	 * @param secciones
	 */
	public void setSeccion(Seccion seccion) {
		this.secciones = seccion;
	}

	/**
	 * CONSTRUCTOR DEL EDIFICIO
	 */
	public Edificio() {
		System.out.println("Se crea el edificio");
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_INFERIOR, 3));
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_MEDIA, 2));
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_SUPERIOR, 1));
		secciones = seccionVector.get(0);
		seccionActual = secciones.getSeccionActual();
		probabilidadSeccion = 0.0;
	}

	/**
	 * Crea una nueva secci�n
	 * 
	 * @param ES
	 */
	public void nuevaSeccion(EstadoSeccion ES) {
		int seccionActual = Juego.getGame().getNiceland().getSeccionActual().getSeccionEnNumero();
		switch (seccionActual) {
		case 0:
			this.secciones = new Seccion(ES, 3);
			break;
		case 1:
			this.secciones = new Seccion(ES, 2);
			break;
		case 2:
			this.secciones = new Seccion(ES, 1);
			break;
		}
	}

	public EstadoSeccion getSeccionActual() {
		return seccionActual;
	}

	public void setSeccionActual(EstadoSeccion seccionActual) {
		this.seccionActual = seccionActual;
	}

}
