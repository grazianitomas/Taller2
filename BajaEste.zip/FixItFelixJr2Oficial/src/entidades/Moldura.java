package entidades;

public class Moldura{

	private boolean hay = false;

	/**
	 * Constructor vacío
	 */
	public Moldura() {
		this.hay = true;
	}
	
	
	
	/**
	 * Retorna si hay moldura
	 * @return
	 */
	public boolean getHay() {
		return this.hay;
	}
	
	/**
	 * Configura si hay moldura
	 * @param b
	 */
	public void setHay(boolean b) {
		this.hay = b;
	}

}
