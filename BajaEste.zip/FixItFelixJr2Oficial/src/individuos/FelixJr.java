package individuos;

import entidades.Posicion;
import modelo.Juego;
import ventanas.*;

public class FelixJr extends Individuo {

	private boolean vivo;
	private boolean invulnerable;
	private static int vidas = 4;
	private static int puntaje = 0;
	private int contadorInv;

	/**
	 * CREA A FELIX EN LAS POCICIONES DADAS
	 * 
	 * @param x
	 * @param y
	 */
	public FelixJr(int x, int y) {
		setPosicion(new Posicion(x, y));
		this.vivo = true;
		vidas -= 1;
		this.invulnerable = true;
	}

	/*
	 * CONFIGURA EL ESTADO DE VIDA DE FELIX
	 */
	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}

	/**
	 * DEVUELVE EL ESTADO DE VIDA DE FELIX
	 * 
	 * @return
	 */
	public boolean getVivo() {
		return this.vivo;
	}

	/**
	 * INSTANCIA LAS CANTIDADES DE VIDA QUE POSEE FELIX
	 * 
	 * @param vida
	 */
	public void setVidas(int vida) {
		vidas = vida;
	}

	/**
	 * DEVUELVE LA CANTIDAD DE VIDAS ACTUALES DE FELIX
	 * 
	 * @return
	 */
	public int getVidas() {
		return vidas;
	}

	/**
	 * CONFIGURA EL PUNTAJE QUE FELIX
	 * 
	 * @param punt
	 */
	public void setPuntaje(int punt) {
		puntaje += punt;
	}

	/**
	 * 
	 * @return
	 */
	public int getPuntaje() {
		return puntaje;
	}

	/**
	 * MUEVE A FELIX DEPENDIENDO EL PAR�METRO PASADO, SI ES POSIBLE
	 * 
	 * @param direc, indica hacia la direcci�n que se desea que Felix se mueva
	 */
	public boolean puedeMoverse(DireccionFelix direc) {
		Ventana aux = Juego.getGame().getNiceland().getSeccion().getVentana(getPosX(), getPosY());
		Posicion siguiente = this.getPosicion().getNextPos(direc);
		if (siguiente.esValida()) {
			int seccionActual = Juego.getGame().getSeccion();
			Ventana nextVentana = Juego.getGame().getNiceland().getSeccionVector().get(seccionActual)
					.getVentana(siguiente.getPosX(), siguiente.getPosY());
			DireccionFelix dirInver = direc.direccionInvertida(direc);
			if (aux.puedeMoverse(direc) && nextVentana.puedeMoverse(dirInver)) {
				if (nextVentana.pastel) {
					this.setInvulnerable(true);
					this.setContadorInv(2000);
				}
				getPosicion().mover(direc);
				return true;
			} else
				return false;
		} else
			return false;
	}

	/**
	 * Retorna si felix es invulnerable
	 * 
	 * @return
	 */
	public boolean getInvulnerable() {
		return invulnerable;
	}

	/**
	 * Configura la invulnerabilidad de Felix
	 * 
	 * @param invulnerable
	 */
	public void setInvulnerable(boolean invulnerable) {
		this.invulnerable = invulnerable;
	}

	/**
	 * Retorna la cantidad de "segundos" que le quedan siendo invulnerable
	 * 
	 * @return
	 */
	public int getContadorInv() {
		return contadorInv;
	}

	/**
	 * Configura la cantidad de "segundos" que le quedan siendo invulnerable
	 * 
	 * @param contadorInv
	 */
	public void setContadorInv(int contadorInv) {
		this.contadorInv = contadorInv;
	}

	/**
	 * DA UN MARTILLAZO PARA REPARAR LA VENTANA PASADA POR PAR�METRO
	 * 
	 * @param vent
	 */
	public boolean darMartillazo(Ventana vent) {
		int puntAnte = this.getPuntaje();
		this.setPuntaje(this.getPuntaje() + vent.repararVentana());
		if (puntAnte < this.getPuntaje()) {
			return true;
		} else
			return false;
	}

	/*
	 * Actualiza el estado de Felix
	 * 
	 */
	@Override
	public void actualizar() {
		if (this.getInvulnerable()) {
			this.setContadorInv(this.getContadorInv() - 1);
			if (this.getContadorInv() == 0)
				this.setInvulnerable(false);
		}

	}

}
