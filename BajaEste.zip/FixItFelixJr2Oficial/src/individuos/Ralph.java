package individuos;

import java.util.Random;

import modelo.Juego;

public class Ralph extends Individuo {
	private EstadoRalph modo;
	private int cantLadrillos;
	private int tirar;
	private static final int posY = 4;
	private boolean limite;
	private int posX;
	private Random rand = new Random();
	private int turnos = 3000;

	/**
	 * CONSTRUCTOR DE RALPH
	 */
	public Ralph() {
		this.tirar = 0;
		this.limite = false;
		this.modo = EstadoRalph.NORMAL;
		this.cantLadrillos = 40;
		setPosX(0);
		setPosY(3);
		System.out.println("Se inicializa Ralph en la posici�n: [4][" + this.getPosY() + "]");
	}

	/**
	 * Retorna si puede tirar
	 * 
	 * @return
	 */
	public int getTirar() {
		return this.tirar;
	}

	/**
	 * Configura el parametro tirar para saber cuando tirar
	 * 
	 * @param i
	 */
	public void setTirar(int i) {
		this.tirar = i;
	}

	/**
	 * SIMULA LOS EFECTOS DE CUANDO RALPH DEMOLE
	 */
	public void demoler() {
		this.setEstado(EstadoRalph.DEMOLEDOR);
		System.out.println("Ralph est� demoliendo.");
		int cont = 0;
		while ((cont < 3) && (this.cantLadrillos > 0)) {
			Juego.getGame().setIndividuo(new Ladrillo(0, rand.nextInt(4), 0));
			this.cantLadrillos -= 1;
			cont++;
		}
		this.setEstado(EstadoRalph.NORMAL);
	}

	/**
	 * VERIFICA SI EST� AL L�MITE DERECHO DEL EDIFICIO
	 * 
	 * @return
	 */
	public boolean isLimite() {
		return limite;
	}

	/**
	 * SE HACE TRUE CUANDO SE ENCUENTRA EN EL L�bMITE DERECHO DEL EDIFICIO
	 * 
	 * @param limite
	 */
	public void setLimite(boolean limite) {
		this.limite = limite;
	}

	// Actualiza el estado de Ralph y demole si le toca
	@Override
	public void actualizar() {
		if (this.getTirar() == 0) {
			this.demoler();
		} else if (this.getTirar() == 2)
			this.setTirar(0);
		this.setTirar(this.getTirar() + 1);
		this.setTurnos(this.getTurnos() - 1);
		if (this.getTurnos() <= 0) {
			this.mover();
			this.setTurnos(3000);
		}

	}

	/**
	 * Movimiento de Ralph
	 */
	private void mover() {
		if (!this.isLimite())
			if (this.getPosY() < 4) {
				this.setPosY(++posX);
			} else {
				this.setLimite(true);
			}
		else if (this.getPosY() > 0) {
			this.setPosY(--posX);
		} else
			this.setLimite(false);

	}

	/*
	 * DEVUELVE LA POSICION DE RALPH ACTUAL
	 */
	public int getPosY() {
		return posY;
	}

	/**
	 * CONFIGURA EL ESTADO ACTUAL DE RALPH
	 * 
	 * @param estado
	 */
	public void setEstado(EstadoRalph estado) {
		this.modo = estado;
	}

	public EstadoRalph getEstado() {
		return this.modo;
	}

	public int getTurnos() {
		return turnos;
	}

	public void setTurnos(int turnos) {
		this.turnos = turnos;
	}

}
