package individuos;

public enum EstadoRalph {
	//ESTADOS EN LOS QUE SE ENCUENTRA RALPH
	NORMAL, DEMOLEDOR;
}
