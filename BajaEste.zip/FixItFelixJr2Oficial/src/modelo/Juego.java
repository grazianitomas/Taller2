package modelo;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import entidades.Posicion;
import individuos.DireccionFelix;
import individuos.FelixJr;
import individuos.Individuo;
import individuos.Ladrillo;
import individuos.Pajaro;
import individuos.Ralph;
import niceland.Edificio;
import niceland.EstadoSeccion;
import ventanas.Ventana;

public class Juego {

	private FelixJr felix;
	private Edificio niceland;
	private Ralph ralph;
	private Nivel nivel;
	private CopyOnWriteArrayList<Ladrillo> ladrillos = new CopyOnWriteArrayList<Ladrillo>();
	private CopyOnWriteArrayList<Individuo> individuos = new CopyOnWriteArrayList<Individuo>();
	private CopyOnWriteArrayList<Pajaro> pajaros = new CopyOnWriteArrayList<Pajaro>();
	private static Juego game;
	private int limiteSeccion = 2000;

	public static Juego getGame() {
		if (game == null) {
			game = new Juego();
		}
		return game;
	}

	public CopyOnWriteArrayList<Ladrillo> getLadrillos() {
		return ladrillos;
	}

	public void setLadrillos(CopyOnWriteArrayList<Ladrillo> ladrillos) {
		this.ladrillos = ladrillos;
	}

	public CopyOnWriteArrayList<Pajaro> getPajaros() {
		return pajaros;
	}

	public void setPajaros(CopyOnWriteArrayList<Pajaro> pajaros) {
		this.pajaros = pajaros;
	}

	public void setIndividuos(CopyOnWriteArrayList<Individuo> individuos) {
		this.individuos = individuos;
	}

	/**
	 * AGREGA UN LADRILLO A LA ARRAYLIST
	 * 
	 * @param L
	 */
	public void agregarLadrillo(Ladrillo L) {
		ladrillos.add(L);
	}

	public CopyOnWriteArrayList<Individuo> getIndividuos() {
		return individuos;
	}

	public Edificio getNiceland() {
		return this.niceland;
	}

	/**
	 * SE INSTANCIA EL JUEGO
	 */
	private Juego() {
		System.out.println("Se inicia el juego");
		nivel = new Nivel();
		niceland = new Edificio();
		niceland.getSeccionVector().get(0).getSeccionActual();
		individuos.add(new Pajaro());
		ralph = new Ralph();
		individuos.add(ralph);
		felix = new FelixJr(2, 2);
	}

	/**
	 * @return the ralph
	 */
	public Posicion getPosRalph() {
		return ralph.getPosicion();
	}

	/**
	 * @param ralph the ralph to set
	 */
	public void setRalph(Ralph ralph) {
		this.ralph = ralph;
	}

	/**
	 * Agrega un individuo al array de individuos
	 * 
	 * @param I
	 */
	public void setIndividuo(Individuo I) {
		this.individuos.add(I);
	}

	/**
	 * Actualiza el estado de los objetos en cada instancia;
	 */
	public void actualizar() {
		getGame().sacarPajaros();
		getGame().sacarLadrillos();
		for (Individuo I : getGame().individuos)
			I.actualizar();
		getGame().realizarPasajeDeNivel();
		if (getGame().getLimiteSeccion() <= 0) {
			getGame().repararTodasLasVentanas();
			getGame().setLimiteSeccion(2000);
		}
		getGame().setLimiteSeccion(getLimiteSeccion() - 1);
	}

	private void repararTodasLasVentanas() {
		EstadoSeccion seccionActual = getGame().getNiceland().getSeccionActual();
		int seccion = seccionActual.getSeccionEnNumero();
		ArrayList<ArrayList<Ventana>> matrizVentanas = getGame().getNiceland().getSeccionVector().get(seccion)
				.getMatrizVentanas();
		for (ArrayList<Ventana> arrayList : matrizVentanas) {
			for (Ventana ventana : arrayList) {
				while (!ventana.getSana()) {
					ventana.repararVentana();
				}
			}
		}
	}

	/*
	 * Verifica si se puede pasar de nivel, y sino simplemente pasa de sección
	 */
	public boolean realizarPasajeDeNivel() {
		boolean paso = false;
		if (getGame().pasarSeccion()) {
			getGame().setLimiteSeccion(2000);
			if (getGame().niceland.getSeccionActual().equals(EstadoSeccion.SECCION_SUPERIOR)) {
				paso = true;
				getGame().nivel.pasarNivel();
				getGame().niceland.setSeccionActual(getGame().niceland.getSeccionActual().proxSeccion());
				getGame().niceland = new Edificio();
				System.out.println("Congratulaciones! Pasaste al nivel "
						+ getGame().nivel.getNivelActual().getNivelesNum(getGame().nivel.getNivelActual()));
			} else {
				getGame().niceland.setSeccionActual(getGame().niceland.getSeccionActual().proxSeccion());
			}
			Thread.currentThread();
			/**
			 * Se duerme el hilo con la intención de evitar errores RAR (Read After Read),
			 * con el pasaje de la sección y la actualización de la gráfica, pasaba que la
			 * lógica tomaba que se pasaba de sección pero la gráfica no.
			 */
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return paso;
	}

	/**
	 * Verifica si felix puede moverse en la dirección dada
	 * 
	 * @param direc
	 * @return
	 */
	public boolean chequear(DireccionFelix direc) {
		return getGame().felix.puedeMoverse(direc);
	}

	/**
	 * ORDENA A FELIX A DAR UN MARTILLAZO EN SU POSICI�N
	 */
	public boolean martillazo() {
		int seccion = getGame().getNiceland().getSeccionActual().getSeccionEnNumero();
		Ventana aReparar = getGame().getNiceland().getSeccionVector().get(seccion)
				.getVentana(getGame().ubicacionFelix().getPosX(), getGame().ubicacionFelix().getPosY());
		boolean seDio = felix.darMartillazo(aReparar);
		return seDio;
	}

	/**
	 * VERIFICA LA COLISION ENTRE FELIX Y ALGO
	 * 
	 * @return
	 */
	public static boolean colisionar() {
		for (Individuo i : getGame().individuos) {
			if (i.colision(getGame().felix.getPosicion())) {
				if (getGame().felix.getVidas() > 0)
					getGame().felix = new FelixJr(2, 2);
				return true;
			}
		}
		return false;
	}

	/**
	 * RETORNA LA POSICI�N ACTUAL DE FELIX
	 * 
	 * @return
	 */
	public Posicion ubicacionFelix() {
		return getGame().felix.getPosicion();
	}

	/**
	 * ELIMINA LOS LADRILLOS QUE SALGAN DEL L�MITE
	 * 
	 * @param juegaso
	 */
	private void sacarLadrillos() {
		ArrayList<Ladrillo> temporal = new ArrayList<Ladrillo>();
		for (Ladrillo e : getGame().ladrillos) {
			if (e.getPosY() > 0) {
				temporal.add(e);
			}
		}
		getGame().ladrillos.removeAll(temporal);
	}

	/**
	 * ELIMINA LOS PAJAROS QUE SE SALGAN DEL JUEGO
	 */
	private void sacarPajaros() {
		ArrayList<Pajaro> temporal = new ArrayList<Pajaro>();
		for (Pajaro p : getGame().pajaros) {
			if ((p.getPosX() > 4) || p.getPosX() < 0) {
				temporal.add(p);
			}
		}
		getGame().pajaros.removeAll(temporal);

	}

	/**
	 * VERIFICA SI SE PUEDE PASAR DE NIVEL
	 * 
	 * @return VERDADERO SI SE PUEDE
	 */
	public boolean pasarSeccion() {
		ArrayList<ArrayList<Ventana>> ventanas;
		EstadoSeccion seccionEnum = getGame().niceland.getSeccionActual();
		int seccion = seccionEnum.getSeccionEnNumero();
		ventanas = niceland.getSeccionVector().get(seccion).getMatrizVentanas();
		for (int i = 0; i < ventanas.size(); i++) {
			for (int j = 0; j < ventanas.get(i).size(); j++) {
				if (!ventanas.get(i).get(j).getSana())
					return false;
			}
		}
		return true;
	}

	/**
	 * IMPLEMENTAR GANAR, VA EN LA PARTE GR�FICA
	 */
	public void ganar() {

	}

	public void mover(DireccionFelix direc) {
		ubicacionFelix().mover(direc);
	}

	/**
	 * Ordena a felix a cambiar la posicion a por la pasada
	 * 
	 * @param pos
	 */
	public void cambiarPosicion(Posicion pos) {
		felix.getPosicion().cambiarPosicion(pos);
	}

	public int getLimiteSeccion() {
		return limiteSeccion;
	}

	public void setLimiteSeccion(int limiteSeccion) {
		this.limiteSeccion = limiteSeccion;
	}

}
