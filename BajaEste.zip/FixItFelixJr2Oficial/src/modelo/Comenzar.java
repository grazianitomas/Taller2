package modelo;

import java.util.*;

import vistas.FrameMenu;

public class Comenzar {

	public static void main(String[] args) {
		Timer timer = new Timer();

		TimerTask task = new TimerTask() {
			

			@Override
			public void run() {
				
				
			}
		};
		
		timer.schedule(task, 10);
		
		
	}
}
