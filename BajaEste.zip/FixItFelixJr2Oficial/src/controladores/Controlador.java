package controladores;

import java.util.TimerTask;

import java.util.Timer;

import modelo.Juego;
import vistas.FrameMenu;
import vistas.GraficaJuego;

public class Controlador {

	Timer timer = new Timer();

	TimerTask task = new TimerTask() {

		@Override
		public void run() {
			Juego.getGame().actualizar();
			GraficaJuego.getGrafica().actualizar();
		}
	};

	public Controlador() {
		FrameMenu.instancia().setCard("Juego");
		GraficaJuego.getGrafica().requestFocus();
		timer.schedule(task, 10, 5);
	}

}
