package controladores;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MiMouseJugar extends MouseAdapter {

	private Controlador controller;

	public MiMouseJugar() {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		try {
//			FrameMenu.instancia().setCard("Juego");
//			GraficaJuego.getGrafica().requestFocus();
			setController(new Controlador());
		} catch (Exception d) {
			d.printStackTrace();
		}
		super.mouseClicked(e);
	}

	public Controlador getController() {
		return controller;
	}

	public void setController(Controlador controller) {
		this.controller = controller;
	}

}
