package controladores;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import entidades.Posicion;
import individuos.DireccionFelix;
import modelo.Juego;
import vistas.GraficaJuego;

/**
 * Maneja los eventos del teclado
 * 
 * @author Emilio
 *
 */
public class MiTecladoEnJuego extends KeyAdapter {

	@Override
	public void keyPressed(KeyEvent e) {
		Posicion pos;
		switch (e.getKeyCode()) {
		case KeyEvent.VK_LEFT:
			if (Juego.getGame().chequearIzquierda()) {

				/**
				 * Por si se quiere mover a la puerta
				 */
				pos = new Posicion(2, 3);
				if (Juego.getGame().ubicacionFelix().equals(pos)) {
					GraficaJuego.getGrafica().moverAPuerta(DireccionFelix.IZQUIERDA);
					Juego.getGame().moverIzquierda();
					break;
				} else {
					/**
					 * Por si quiere salir de la puerta
					 */
					pos = new Posicion(2, 2);
					if (Juego.getGame().ubicacionFelix().equals(pos)) {
						GraficaJuego.getGrafica().salirDePuerta(DireccionFelix.IZQUIERDA);
						Juego.getGame().moverIzquierda();
						break;
					} else {
						GraficaJuego.getGrafica().moverIzq();
						Juego.getGame().moverIzquierda();
						break;
					}
				}
			}
			break;
		case KeyEvent.VK_RIGHT:
			if (Juego.getGame().chequearDerecha()) {

				/**
				 * Por si se quiere mover a la puerta
				 */
				pos = new Posicion(2, 1);
				if (Juego.getGame().ubicacionFelix().equals(pos)) {
					GraficaJuego.getGrafica().moverAPuerta(DireccionFelix.DERECHA);
					Juego.getGame().moverDerecha();
					break;
				} else {
					/**
					 * Por si quiere salir de la puerta
					 */
					pos = new Posicion(2, 2);
					if (Juego.getGame().ubicacionFelix().equals(pos)) {
						GraficaJuego.getGrafica().salirDePuerta(DireccionFelix.DERECHA);
						Juego.getGame().moverDerecha();
						break;
					} else {
						GraficaJuego.getGrafica().moverDer();
						Juego.getGame().moverDerecha();
						break;
					}
				}
			}
			;
			break;
		case KeyEvent.VK_DOWN:
			if (Juego.getGame().chequearAbajo()) {

				/**
				 * Por si se quiere mover a la puerta
				 */
				pos = new Posicion(1, 2);
				if (Juego.getGame().ubicacionFelix().equals(pos)) {
					GraficaJuego.getGrafica().moverAPuerta(DireccionFelix.ABAJO);
					Juego.getGame().moverAbajo();
				} else {
					GraficaJuego.getGrafica().moverAbajo();
					Juego.getGame().moverAbajo();
				}

			}
			;
			break;
		case KeyEvent.VK_UP:
			if (Juego.getGame().chequearArriba()) {

				/**
				 * Por si quiere salir de la puerta
				 */
				pos = new Posicion(2, 2);
				if (Juego.getGame().ubicacionFelix().equals(pos)) {
					GraficaJuego.getGrafica().salirDePuerta(DireccionFelix.ARRIBA);
					Juego.getGame().moverArriba();
				} else {
					GraficaJuego.getGrafica().moverUp();
					Juego.getGame().moverArriba();
				}

			}
			;
			break;
		case KeyEvent.VK_SPACE:
			if (Juego.getGame().martillazo()) {
				GraficaJuego.getGrafica().repararVentana();
				if (Juego.getGame().pasarSeccion()) {
					GraficaJuego.getGrafica().setPasar(true);
				}
			} else {

			}
			break;
		case KeyEvent.VK_ESCAPE:
			System.out.println(e.getKeyCode());
			break;
		default:
			System.out.println(e.getKeyCode());
			System.out.println("Ésta tecla no la conozco");
			break;
		}
		super.keyPressed(e);
	}
}