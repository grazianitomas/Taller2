package controladores;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import individuos.DireccionFelix;
import modelo.Juego;
import vistas.GraficaJuego;

/**
 * Maneja los eventos del teclado
 * 
 * @author Emilio
 *
 */
public class MiTecladoEnJuego extends KeyAdapter {

	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_LEFT:
			Juego.getGame().chequear(DireccionFelix.IZQUIERDA);
			break;
		case KeyEvent.VK_RIGHT:
			Juego.getGame().chequear(DireccionFelix.DERECHA);
			break;
		case KeyEvent.VK_DOWN:
			Juego.getGame().chequear(DireccionFelix.ABAJO);
			break;
		case KeyEvent.VK_UP:
			Juego.getGame().chequear(DireccionFelix.ARRIBA);
			break;
		case KeyEvent.VK_SPACE:
			if (Juego.getGame().martillazo())
				GraficaJuego.getGrafica().repararVentana();
			break;
		case KeyEvent.VK_ESCAPE:
			System.out.println(e.getKeyCode());
			break;
		default:
			System.out.println(e.getKeyCode());
			System.out.println("Ésta tecla no la conozco");
			break;
		}
		GraficaJuego.getGrafica().actualizar();
		super.keyPressed(e);
	}
}