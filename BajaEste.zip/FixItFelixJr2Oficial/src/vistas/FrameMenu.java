package vistas;

import java.awt.CardLayout;

import javax.swing.JFrame;

public class FrameMenu extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CardLayout card = new CardLayout();
	private static FrameMenu getInstance;

	public static FrameMenu instancia() {
		if (getInstance == null) {
			getInstance = new FrameMenu();
		}
		return getInstance;
	}

	public FrameMenu() {
		setSize(480, 740);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(card);
		getContentPane().add(new Menu(), "Menu");
		getContentPane().add(new Top5(), "Top5");
		getContentPane().add(GraficaJuego.getGrafica(), "Juego");
		card.show(getContentPane(), "Menu");
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public CardLayout getCard() {
		return this.card;
	}

	public void setCard(String name) {
		card.show(getContentPane(), name);
	}

	public static void main(String[] args) {
		getInstance = new FrameMenu();
	}

}
