package ventanas;

import java.util.ArrayList;
import java.util.Random;

import entidades.Maceta;
import entidades.Moldura;
import individuos.DireccionFelix;

public class DosHojas extends Ventana {

	private Random rand = new Random();

	/*
	 * CONSTRUCTOR DE LA VENTANA CON HOJAS
	 */
	public DosHojas() {
		super();
		generarEstado(rand.nextInt());
		this.tipo = TipoVentana.DOS_HOJAS;

	}

	/*
	 * CONTRUCTOR DE LAS VENTANA CON HOJAS TENIENDO EN CUENTA LA PROBABILIDAD DE
	 * ROTO
	 */
	public DosHojas(double proba) {
		super();
		this.tipo = TipoVentana.DOS_HOJAS;
		setMaceta(new Maceta());
		setMoldura(new Moldura());
//		if ((rand.nextDouble() / proba) > 0.3) {
//			if ((rand.nextDouble() / proba) > 0.6)
//				getMoldura().setHay(true);
//			else
//				getMoldura().setHay(false);
//			getMaceta().setHay(true);
//		} else
		getMoldura().setHay(false);
		getMaceta().setHay(false);
		this.paneles.add(new Panel(1000));
		this.paneles.add(new Panel(1000, true));
		setPuntaje();
		generarEstado((int) (rand.nextInt(4) / proba * 0.5));
	}

	/*
	 * GENERA EL ESTADO DE LA VENTANA
	 */
	private void generarEstado(int i) {
		switch (i) {
		case 1:
			setEstado(OpenClose.CERRADA);
			break;
		case 0:
			setEstado(OpenClose.ABIERTA_AMBOS);
			break;
		case 2:
			setEstado(OpenClose.ABIERTA_DERECHA);
			break;
		case 3:
			setEstado(OpenClose.ABIERTA_IZQUIERDA);
			break;
		default:
			break;
		}
	}

	/**
	 * Reemplaza el mÃ©todo puedeMoverse de la superclase Ventana
	 */
	@Override
	public boolean puedeMoverse(DireccionFelix direc) {
		boolean puede = true;
		switch (direc) {
		case ARRIBA: {
			if (!(this.getMoldura() == null))
				return puede;
			else
				puede = false;
		}
			break;
		case ABAJO:
			if (!(this.getMaceta() == null))
				return puede;
			else
				puede = false;
			break;
		case DERECHA:
			if (!(getEstado().equals(OpenClose.ABIERTA_DERECHA)))
				if (!(getEstado().equals(OpenClose.ABIERTA_AMBOS)))
					return puede;
				else
					puede = false;
			break;
		case IZQUIERDA:
			if (!(this.getEstado().equals(OpenClose.ABIERTA_IZQUIERDA)))
				if (!(getEstado().equals(OpenClose.ABIERTA_AMBOS)))
					return puede;
				else
					puede = false;
			break;
		case QUIETO: {
			return puede;
		}
		}
		return puede;
	}

	@Override
	public void setPuntaje() {
		puntaje = new ArrayList<Integer>();
		for (int i = 0; i < paneles.size(); i++) {
			puntaje.add(100);
		}
	}

	@Override
	public ArrayList<Integer> getPuntaje() {
		return puntaje;
	}

}
