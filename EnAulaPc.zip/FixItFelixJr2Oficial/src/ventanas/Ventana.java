package ventanas;

import java.util.ArrayList;

import entidades.Maceta;
import entidades.Moldura;
import individuos.DireccionFelix;

public abstract class Ventana {

	private Maceta maceta;
	private Moldura moldura;
	private double probabilidad;
	protected ArrayList<Panel> paneles;
	private boolean pastel;
	protected TipoVentana tipo;
	protected OpenClose estado;
	protected ArrayList<Integer> puntaje;

	public abstract ArrayList<Integer> getPuntaje();

	public abstract void setPuntaje();

	public OpenClose getEstado() {
		return estado;
	}

	public void setEstado(OpenClose estado) {
		this.estado = estado;
	}

	public TipoVentana getTipo() {
		return tipo;
	}

	public void setTipo(TipoVentana tipo) {
		this.tipo = tipo;
	}

	public boolean getPastel() {
		return pastel;
	}

	public void setPastel(boolean pastel) {
		this.pastel = pastel;
	}

	/**
	 * CONSTRUCTOR VAC�O
	 */
	public Ventana() {
		paneles = new ArrayList<Panel>();
	}

	/**
	 * CONSTRUCTOR QUE SOLO INSTANCIA MACETAS Y TECHO
	 * 
	 * @param maceta
	 * @param techo
	 */
	public Ventana(Maceta maceta, Moldura moldura) {
		paneles = new ArrayList<Panel>();
		this.maceta = maceta;
		this.moldura = moldura;
	}

	/**
	 * CONSTRUCTOR QUE INSTANCIA TAMBIÉN LOS PANELES
	 * 
	 * @param maceta
	 * @param techo
	 * @param paneles panel a configurar
	 */
	public Ventana(Maceta maceta, Moldura moldura, ArrayList<Panel> paneles) {

		this.paneles = new ArrayList<Panel>();
		this.maceta = maceta;
		this.moldura = moldura;
		this.paneles = paneles;
	}

	/**
	 * RETORNA VERDADERO SI HAY MACETA EN LA VENTANA
	 * 
	 * @return verdadero o falso
	 */
	public Maceta getMaceta() {
		return maceta;
	}

	/**
	 * CONFIGURA UNA MACETA EN LA VENTANA
	 * 
	 * @param maceta
	 */
	public void setMaceta(Maceta maceta) {
		this.maceta = maceta;
	}

	/**
	 * RETORNA VERDADERO SI HAY TECHO EN LA VENTANA
	 * 
	 * @return verdadero o falso
	 */
	public Moldura getMoldura() {
		return this.moldura;
	}

	/**
	 * CONFIGURA UN TECHO O MOLDURA EN LA VENTANA
	 * 
	 * @param techo
	 */
	public void setMoldura(Moldura moldura) {
		this.moldura = moldura;
	}

	/**
	 * REPARA LA VENTANA ACTUAL
	 * 
	 * @return retorna 100 si se reparó, o 0 si ya estaba reparada
	 */
	public int repararVentana() {
		if (!this.getSana()) {
			boolean sano = false;
			int i = 0;
			int punt = 0;
			Integer aEliminar;
			int size = puntaje.size();
			while ((!sano) && (i < size)) {
				if (!paneles.get(i).getEstado().equals(EstadoPanel.SANO)) {
					paneles.get(i).repararPanel();
					punt = puntaje.get(i);
					aEliminar = punt;
					
					return punt;
				}
				i++;
			}
		}
		return 0;
	}

	/**
	 * RETORNA VERDADERO SI LA VENTANA ACTUAL SE ENCUENTRA COMPLETAMENTE SANA
	 * 
	 * @return verdadero o falso
	 */
	public boolean getSana() {
		boolean panelSano = true;
		int i = 0;
		int size = paneles.size();
		while ((panelSano) && (i < size)) {
			if (!paneles.get(i).getEstado().equals(EstadoPanel.SANO)) {
				panelSano = false;
			}
			i++;
		}
		return panelSano;
	}

	/**
	 * Calcula la cantidad de paneles rotos, semirotos y sanos
	 * 
	 * @return Retorna la cantidad de c/panel, en el orden dicho antes.
	 */
	public int getCantRotos() {
		int cant = 0;
		int size = paneles.size();
		for (int i = 0; i < size; i++) {
			switch (paneles.get(i).getEstado()) {
			case ROTO:
				cant += 1;
				break;
			case SEMI_ROTO:
				cant += 1;
				break;
			case SANO:
				cant = cant + 0;
				break;
			default:
				break;
			}
		}
		return cant;
	}

	/**
	 * CONFIGURA LA PROBABILIDAD DE QUE LOS PANELES ESTEN ROTOS
	 * 
	 * @param proba probabilidad de que los planeles esten rotos
	 */
	public void setProba(double proba) {
		this.probabilidad = proba;
	}

	/**
	 * RETORNA LA PROBABILIDAD DE QUE LOS PANELES ESTEN ROTOS
	 * 
	 * @return double
	 */
	public double getProba() {
		return this.probabilidad;
	}

	/**
	 * Retorna la ventana actual
	 * 
	 * @return
	 */
	public Ventana getVentana() {
		return this;
	}

	/**
	 * Verifica si Felix puede moverse en direcciones de arriba o abajo
	 * 
	 * @param direc direccion a la que se solicita moverse
	 * @return verdadero o falso
	 */
	public boolean puedeMoverse(DireccionFelix direc) {
		if (direc.equals(DireccionFelix.ARRIBA)) {
			if (!(getMoldura().getHay())) {
				return true;
			} else
				return false;
		} else {
			if (!(getMaceta().getHay())) {
				return true;
			} else
				return false;
		}
	}

	public ArrayList<Panel> getPaneles() {
		return paneles;
	}

	public void setPaneles(ArrayList<Panel> paneles) {
		this.paneles = paneles;
	}

}
