package ventanas;

import java.util.ArrayList;

import entidades.Maceta;
import entidades.Moldura;

public class Puerta extends Ventana {

	/*
	 * CREA LA PUERTA CON LA PROBABILIDAD DE PANELES ROTOS PASADA POR PARáMETRO
	 */
	public Puerta(double proba) {
		super(new Maceta(), new Moldura());
		this.tipo = TipoVentana.PUERTA;
		getMaceta().setHay(false);
		getMoldura().setHay(false);
		for (int i = 0; i < 4; i++)
			this.paneles.add(new Panel(proba));
		setPuntaje();
	}

	@Override
	public void setPuntaje() {
		puntaje = new ArrayList<Integer>();
		for (int i = 0; i < paneles.size(); i++) {
			puntaje.add(100);
		}
	}

	@Override
	public ArrayList<Integer> getPuntaje() {
		return puntaje;
	}

}
