package vistas;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controladores.MiTecladoEnJuego;
import modelo.Juego;
import niceland.EstadoSeccion;
import ventanas.OpenClose;
import ventanas.TipoVentana;
import ventanas.Ventana;

public class GraficaJuego extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int intermedio = 0;
	private int columnaPrevRalph = 0;

	/**
	 * @return the columnaPrevRalph
	 */
	public int getColumnaPrevRalph() {
		return columnaPrevRalph;
	}

	/**
	 * @param columnaPrevRalph the columnaPrevRalph to set
	 */
	public void setColumnaPrevRalph(int columnaPrevRalph) {
		this.columnaPrevRalph = columnaPrevRalph;
	}

	/**
	 * @return the columnaSigRalph
	 */
	public int getColumnaSigRalph() {
		return columnaSigRalph;
	}

	/**
	 * @param columnaSigRalph the columnaSigRalph to set
	 */
	public void setColumnaSigRalph(int columnaSigRalph) {
		this.columnaSigRalph = columnaSigRalph;
	}

	private int columnaActualRalph = 0;
	private int columnaSigRalph = 0;
	private ArrayList<JLabel> pasto = new ArrayList<JLabel>();
	private JLabel felix = new JLabel();
	private JLabel ladrillo = new JLabel();
	private JLabel pajaro = new JLabel();
	private JLabel ralph = new JLabel();
	private JLabel torta1 = new JLabel();
	private JLabel torta2 = new JLabel();
	private JLabel seccion1 = new JLabel();
	private JLabel seccion2 = new JLabel();
	private JLabel seccion3 = new JLabel();
	private MiTecladoEnJuego teclado = new MiTecladoEnJuego();
	private CopyOnWriteArrayList<JLabel> ladrillos = new CopyOnWriteArrayList<JLabel>();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion1 = new ArrayList<ArrayList<JLabel>>();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion2 = new ArrayList<ArrayList<JLabel>>();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion3 = new ArrayList<ArrayList<JLabel>>();
	private int contadorPasajeDeSeccion = 2000;
	private int[] posicionVentanasFila = { 478, 560, 638 };
	private int[] posicionVentanasCol = { 105, 155, 210, 265, 315 };
	private boolean pasar = false;
	private int cont = 0;

	public int[] getPosicionVentanasCol() {
		return posicionVentanasCol;
	}

	public void setPosicionVentanasCol(int[] posicionVentanasCol) {
		this.posicionVentanasCol = posicionVentanasCol;
	}

	public int[] getPosicionVentanasFila() {
		return posicionVentanasFila;
	}

	public void setPosicionVentanasFila(int[] posicionVentanasFila) {
		this.posicionVentanasFila = posicionVentanasFila;
	}

	/**
	 * @return the contadorPasajeDeSeccion
	 */
	public int getContadorPasajeDeSeccion() {
		return contadorPasajeDeSeccion;
	}

	/**
	 * @param contadorPasajeDeSeccion the contadorPasajeDeSeccion to set
	 */
	public void setContadorPasajeDeSeccion(int contadorPasajeDeSeccion) {
		this.contadorPasajeDeSeccion = contadorPasajeDeSeccion;
	}

	private Random rand = new Random();
	private boolean der = rand.nextBoolean();

	private static GraficaJuego getInstance;

	/**
	 * Retorna la instancia estática de la gráfica
	 * 
	 * @return
	 */
	public static GraficaJuego getGrafica() {
		if (getInstance == null)
			getInstance = new GraficaJuego();
		return getInstance;
	}

	/**
	 * Constructor de la gráfica
	 */
	public GraficaJuego() {
		setSize(480, 740);
		setVisible(false);
		setLayout(null);
		addKeyListener(teclado);
		setBackground(Color.BLACK);
		/**
		 * Se realiza ésta excepción por si no encuentra las imágenes para los JLabels
		 */
		try {
			this.buscarImagenes();
		} catch (Exception e) {
			e.printStackTrace();
		}
		obtenerColumnasRalph();
		int x = 0;
		for (JLabel J : pasto) {
			J.setBounds(x, 693, 24, 18);
			add(J);
			if (x == 72)
				x += 263;
			x += 24;
		}
		felix.setBounds(207, 660, 35, 51);
		add(felix);
		ralph.setBounds(185, 380, 70, 84);
		add(ralph);
		graficarSeccion1();
		graficarSeccion2();
		graficarSeccion3();
		seccion1.setBounds(70, 462, 315, 249);
		add(seccion1);
		seccion2.setBounds(70, 213, 315, 249);
		add(seccion2);
		seccion3.setBounds(70, -92, 315, 306);
		add(seccion3);
		setFocusable(true);
		setVisible(true);
	}

	private void obtenerColumnasRalph() {
		columnaActualRalph = Juego.getGame().getPosRalph().getPosY();
		if (der) {
			if (columnaActualRalph < 4)
				columnaSigRalph = Juego.getGame().getPosRalph().getPosY() + 1;
			else
				columnaSigRalph = Juego.getGame().getPosRalph().getPosY();
		} else {
			if (columnaActualRalph > 0)
				columnaPrevRalph = Juego.getGame().getPosRalph().getPosY() - 1;
			else
				columnaPrevRalph = Juego.getGame().getPosRalph().getPosY();
		}
	}

	/**
	 * @return the pasar
	 */
	public boolean getPasar() {
		return pasar;
	}

	/**
	 * @param pasar the pasar to set
	 */
	public void setPasar(boolean pasar) {
		this.pasar = pasar;
	}

	/**
	 * Grafica los ladrillos que existan
	 */
	public void graficarLadrillos() {
		int i = 0;
		int random = 0;
		for (JLabel L : getGrafica().ladrillos) {
			while (i < 3) {
				random = rand.nextInt(3);
				if (random == 0) {
					L.setLocation(ralph.getX() + rand.nextInt(25), ralph.getY() + 84);
				} else {
					if (random == 1) {
						L.setLocation(ralph.getX() - rand.nextInt(25), ralph.getY() + 84);
					} else {
						L.setLocation(ralph.getX(), ralph.getY() + 84);
					}
				}
				add(L);
				L.repaint();
				i++;
			}
			if (i == 3)
				break;
		}
	}

	/**
	 * Agrega ladrillos cuando se generen en la lógica
	 */
	public void agregarLadrillos() {
		int sizeGame = Juego.getGame().getLadrillos().size();
		int sizeGraf = getGrafica().ladrillos.size();
		if (sizeGame > sizeGraf)
			for (int i = sizeGraf; i < sizeGame; i++) {
				ladrillos.add(ladrillo);
			}
	}

	/**
	 * Saca los ladrillos de el arreglo de ladrillos y del juego una vez salgan del
	 * mapa
	 */
	public void sacarLadrillos() {
		for (JLabel e : getGrafica().ladrillos) {
			if (e.getY() > 740) {
				ladrillos.remove(e);
				remove(e);
			}
		}
	}

	/**
	 * Realiza el movimiento de los ladrillos
	 */
	public void movimientoLadrillos() {
		for (JLabel L : getGrafica().ladrillos) {
			L.setLocation(L.getX(), L.getY() + 1);
			L.repaint();
		}
	}

	/**
	 * Realiza el pasaje de sección en caso de que se pueda
	 */
	public void pasajeSeccion() {
		if (Juego.getGame().pasarSeccion()) {
			getGrafica().subirSeccion();
		}
	}

	/**
	 * Realiza lo gráfico con respecto a pasar de nivel
	 */
	private void subirSeccion() {
		getGrafica().removeKeyListener(teclado);
		for (int i = 0; i < 249; i++) {
			seccion1.setLocation(seccion1.getX(), seccion1.getY() + 1);
			seccion1.repaint();
			seccion2.setLocation(seccion2.getX(), seccion2.getY() + 1);
			seccion2.repaint();
			seccion3.setLocation(seccion3.getX(), seccion3.getY() + 1);
			seccion3.repaint();
			for (JLabel p : pasto) {
				p.setLocation(p.getX(), p.getY() + 1);
				p.repaint();
			}
			for (ArrayList<JLabel> AL : ventanasSeccion1) {
				for (JLabel V : AL) {
					V.setLocation(V.getX(), V.getY() + 1);
					V.repaint();
				}
			}
			for (ArrayList<JLabel> AL : ventanasSeccion2) {
				for (JLabel V : AL) {
					V.setLocation(V.getX(), V.getY() + 1);
					V.repaint();
				}
			}
			for (ArrayList<JLabel> AL : ventanasSeccion3) {
				for (JLabel V : AL) {
					V.setLocation(V.getX(), V.getY() + 1);
					V.repaint();
				}
			}
		}
		getGrafica().addKeyListener(teclado);
	}

	/**
	 * Busca todas las imagenes de los JLabels
	 */
	private void buscarImagenes() {
		felix.setIcon(new ImageIcon(getClass().getClassLoader().getResource("felix/slice136_@.png")));
		ladrillo.setIcon(new ImageIcon(getClass().getClassLoader().getResource("rocas/slice10_10.png")));
		pajaro.setIcon(new ImageIcon(getClass().getClassLoader().getResource("pajaro/slice09_09.png")));
		ralph.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ralph/slice146_@.png")));
		seccion1.setIcon(new ImageIcon(getClass().getClassLoader().getResource("edificio/edificio_150_seccion1.png")));
		seccion2.setIcon(new ImageIcon(getClass().getClassLoader().getResource("edificio/edificio_150_seccion2.png")));
		seccion3.setIcon(new ImageIcon(getClass().getClassLoader().getResource("edificio/edificio_150_seccion3.png")));
		torta1.setIcon(new ImageIcon(getClass().getClassLoader().getResource("pastel/slice12_12.png")));
		torta2.setIcon(new ImageIcon(getClass().getClassLoader().getResource("pastel/slice13_13.png")));
		for (int i = 0; i < 9; i++) {
			pasto.add(new JLabel());
			pasto.get(i).setIcon(new ImageIcon(getClass().getClassLoader().getResource("pasto.png")));
		}
		/**
		 * Se crean éstas excepciones por si no llegara a inicializarse la clase Juego,
		 * de donde se obtiene los datos de las ventanas
		 */
		try {
			graficasVentanasSeccion1();
		} catch (ExceptionInInitializerError e) {
			e.printStackTrace();
		}
		try {
			graficasVentanasSeccion2();
		} catch (ExceptionInInitializerError e) {
			e.printStackTrace();
		}
		try {
			graficasVentanasSeccion3();
		} catch (ExceptionInInitializerError e) {
			e.printStackTrace();
		}
	}

	/**
	 * Asigna la gr�fica de ventana correspondiente a cada ventana dependiendo de
	 * sus paneles rotos en la instancia de juego
	 */
	private void graficasVentanasSeccion1() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(0).getVentana(i, j);
				int cant = window.getCantRotos();
				if (i == 2 && j == 2) {
					graficarPuerta(ventana, cant);
				} else if (i == 1 && j == 2) {
					graficarSemicircular(ventana, cant);
				} else {
					if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
						graficarAmericanas(ventana, window);
					} else {
						graficarVentana(ventana, cant);
					}
				}
				ventanas[j] = ventana;

			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion1.add(fila);

		}
	}

	/**
	 * Grafica las persianas americanas
	 * 
	 * @param ventana
	 * @param window
	 */
	public void graficarAmericanas(JLabel ventana, Ventana window) {
		OpenClose estado = window.getEstado();
		switch (estado) {
		case ABIERTA_AMBOS:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice106_@.png")));
			break;
		case ABIERTA_DERECHA:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice108_@.png")));
			break;
		case ABIERTA_IZQUIERDA:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice107_@.png")));
			break;
		case CERRADA:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice105_@.png")));
		default:
			break;
		}
	}

	/**
	 * Grafica la puerta
	 * 
	 * @param ventana
	 * @param cant
	 */
	public void graficarPuerta(JLabel ventana, int cant) {
		switch (cant) {
		case 0:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/pb_paneles_sanos.png")));
			break;
		case 1:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/pb_panelesrotos_1.png")));
			break;
		case 2:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/pb_panelesrotos_2.png")));
			break;
		case 3:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/pb_panelesrotos_3.png")));
			break;
		case 4:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/pb_panelesrotos_4.png")));
			break;
		}
	}

	/**
	 * Grafica la semicircular
	 * 
	 * @param ventana
	 * @param cant
	 */
	public void graficarSemicircular(JLabel ventana, int cant) {
		switch (cant) {
		case 0:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_paneles_sanos.png")));
			break;
		case 1:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_1.png")));
			break;
		case 2:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_2.png")));
			break;
		case 3:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_3.png")));
			break;
		case 4:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_4.png")));
			break;
		case 5:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_5.png")));
			break;
		case 6:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_6.png")));
			break;
		case 7:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_7.png")));
			break;
		case 8:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_8.png")));
			break;
		case 9:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_9.png")));
			break;
		case 10:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_10.png")));
			break;
		case 11:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_11.png")));
			break;
		case 12:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_12.png")));
			break;
		case 13:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_13.png")));
			break;
		case 14:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_14.png")));
			break;
		case 15:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_15.png")));
			break;
		case 16:
			ventana.setIcon(
					new ImageIcon(getClass().getClassLoader().getResource("semicirculares/1ro_panelesrotos_16.png")));
			break;
		}
	}

	/**
	 * Grafica las ventanas de la seccion 2
	 */
	private void graficasVentanasSeccion2() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(1).getVentana(i, j);
				int cant = window.getCantRotos();

				if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
					graficarAmericanas(ventana, window);
				} else {
					graficarVentana(ventana, cant);
				}
				ventanas[j] = ventana;
			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion2.add(fila);
		}
	}

	/**
	 * Grafica las ventanas de la seccion 3
	 */
	private void graficasVentanasSeccion3() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(2).getVentana(i, j);
				int cant = window.getCantRotos();
				if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
					graficarAmericanas(ventana, window);
				} else {
					graficarVentana(ventana, cant);
				}
				ventanas[j] = ventana;
			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion3.add(fila);
		}
	}

	/**
	 * Grafica una ventana comun
	 * 
	 * @param ventana
	 * @param cant
	 */
	public void graficarVentana(JLabel ventana, int cant) {
		switch (cant) {
		case 0:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice100_@.png")));
			break;
		case 1:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice24_24.png")));
			break;
		case 2:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice113_@.png")));
			break;
		case 3:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice104_@.png")));
			break;
		case 4:
			ventana.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ventanas_y_panel/slice103_@.png")));
			break;
		}
	}

	public void graficarMartillazo() {
		for (int i = 0; i < 1000; i++)
			if (i / 500 == 2) {
				felix.setIcon(new ImageIcon(getClass().getClassLoader().getResource("felix/slice111_@.png")));
				felix.repaint();
			} else {
				felix.setIcon(new ImageIcon(getClass().getClassLoader().getResource("felix/slice135_@.png")));
				felix.repaint();
			}
	}

	/**
	 * Actualiza la posición de Felix con respecto a la de la lógica
	 */
	private void actualizarFelix() {
		int x = Juego.getGame().ubicacionFelix().getPosX();
		int y = Juego.getGame().ubicacionFelix().getPosY();
		switch (Juego.getGame().getSeccionEnum()) {
		case SECCION_INFERIOR:
			if (y == 2 && x == 2) {
				felix.setLocation(207, 660);
			} else if (y == 2 && x == 1) {
				felix.setLocation(210, 560);
			} else {
				felix.setLocation(getPosicionVentanasCol()[y], getPosicionVentanasFila()[x]);
			}
			break;
		case SECCION_MEDIA:
			felix.setLocation(getPosicionVentanasCol()[y], getPosicionVentanasFila()[x]);
			break;
		case SECCION_SUPERIOR:
			felix.setLocation(getPosicionVentanasCol()[y], getPosicionVentanasFila()[x]);
			break;
		default:
			felix.setLocation(getPosicionVentanasCol()[y], getPosicionVentanasFila()[x]);
			break;
		}
		felix.repaint();
	}

	/**
	 * Grafica la reparacion de una ventana
	 */
	public void repararVentana() {
		Icon prev = felix.getIcon();
		felix.setIcon(new ImageIcon(getClass().getClassLoader().getResource("felix/slice137_@.png")));
		felix.repaint();
		EstadoSeccion seccion = Juego.getGame().getSeccionEnum();
		int x = Juego.getGame().ubicacionFelix().getPosX();
		int y = Juego.getGame().ubicacionFelix().getPosY();
		int seccionActual = seccion.getSeccionNum(seccion);
		Ventana vent = Juego.getGame().getNiceland().getSeccionVector().get(seccionActual).getVentana(x, y);
		int cant = vent.getCantRotos();
		switch (seccion) {
		case SECCION_INFERIOR:
			if (x == 2 && y == 2) {
				graficarPuerta(ventanasSeccion1.get(x).get(y), cant);
				ventanasSeccion1.get(x).get(y).repaint();
			} else if (x == 1 && y == 2) {
				graficarSemicircular(ventanasSeccion1.get(x).get(y), cant);
				ventanasSeccion1.get(x).get(y).repaint();
			} else {
				if (vent.getTipo().equals(TipoVentana.COMUN)) {
					graficarVentana(ventanasSeccion1.get(x).get(y), cant);
					ventanasSeccion1.get(x).get(y).repaint();
				}
			}
			break;
		case SECCION_MEDIA:
			if (vent.getTipo().equals(TipoVentana.COMUN)) {
				graficarVentana(ventanasSeccion2.get(x).get(y), cant);
				ventanasSeccion2.get(x).get(y).repaint();
			}
			break;
		case SECCION_SUPERIOR:
			if (vent.getTipo().equals(TipoVentana.COMUN)) {
				graficarVentana(ventanasSeccion3.get(x).get(y), cant);
				ventanasSeccion3.get(x).get(y).repaint();
			}
			break;
		}
		felix.setIcon(prev);
		felix.repaint();

	}

	/**
	 * Grafica las ventanas de la seccion1
	 */
	private void graficarSeccion1() {
		ventanasSeccion1.get(0).get(0).setBounds(105, 478, 38, 60);
		add(ventanasSeccion1.get(0).get(0));
		ventanasSeccion1.get(0).get(1).setBounds(155, 478, 38, 60);
		add(ventanasSeccion1.get(0).get(1));
		ventanasSeccion1.get(0).get(2).setBounds(210, 478, 38, 60);
		add(ventanasSeccion1.get(0).get(2));
		ventanasSeccion1.get(0).get(3).setBounds(265, 478, 38, 60);
		add(ventanasSeccion1.get(0).get(3));
		ventanasSeccion1.get(0).get(4).setBounds(315, 478, 38, 60);
		add(ventanasSeccion1.get(0).get(4));

		ventanasSeccion1.get(1).get(0).setBounds(105, 560, 38, 60);
		add(ventanasSeccion1.get(1).get(0));
		ventanasSeccion1.get(1).get(1).setBounds(155, 560, 38, 60);
		add(ventanasSeccion1.get(1).get(1));
		ventanasSeccion1.get(1).get(2).setBounds(199, 560, 61, 56);
		add(ventanasSeccion1.get(1).get(2));
		ventanasSeccion1.get(1).get(3).setBounds(265, 560, 38, 60);
		add(ventanasSeccion1.get(1).get(3));
		ventanasSeccion1.get(1).get(4).setBounds(315, 560, 38, 60);
		add(ventanasSeccion1.get(1).get(4));

		ventanasSeccion1.get(2).get(0).setBounds(105, 638, 38, 60);
		add(ventanasSeccion1.get(2).get(0));
		ventanasSeccion1.get(2).get(1).setBounds(155, 638, 38, 60);
		add(ventanasSeccion1.get(2).get(1));
		ventanasSeccion1.get(2).get(2).setBounds(199, 615, 61, 97);
		add(ventanasSeccion1.get(2).get(2));
		ventanasSeccion1.get(2).get(3).setBounds(265, 638, 38, 60);
		add(ventanasSeccion1.get(2).get(3));
		ventanasSeccion1.get(2).get(4).setBounds(315, 638, 38, 60);
		add(ventanasSeccion1.get(2).get(4));
	}

	/**
	 * Grafica las ventanas de la seccion2
	 */
	public void graficarSeccion2() {
		ventanasSeccion2.get(0).get(0).setBounds(105, 235, 38, 60);
		add(ventanasSeccion2.get(0).get(0));
		ventanasSeccion2.get(0).get(1).setBounds(155, 235, 38, 60);
		add(ventanasSeccion2.get(0).get(1));
		ventanasSeccion2.get(0).get(2).setBounds(210, 235, 38, 60);
		add(ventanasSeccion2.get(0).get(2));
		ventanasSeccion2.get(0).get(3).setBounds(265, 235, 38, 60);
		add(ventanasSeccion2.get(0).get(3));
		ventanasSeccion2.get(0).get(4).setBounds(315, 235, 38, 60);
		add(ventanasSeccion2.get(0).get(4));

		ventanasSeccion2.get(1).get(0).setBounds(105, 312, 38, 60);
		add(ventanasSeccion2.get(1).get(0));
		ventanasSeccion2.get(1).get(1).setBounds(155, 312, 38, 60);
		add(ventanasSeccion2.get(1).get(1));
		ventanasSeccion2.get(1).get(2).setBounds(210, 312, 38, 60);
		add(ventanasSeccion2.get(1).get(2));
		ventanasSeccion2.get(1).get(3).setBounds(265, 312, 38, 60);
		add(ventanasSeccion2.get(1).get(3));
		ventanasSeccion2.get(1).get(4).setBounds(315, 312, 38, 60);
		add(ventanasSeccion2.get(1).get(4));

		ventanasSeccion2.get(2).get(0).setBounds(105, 389, 38, 60);
		add(ventanasSeccion2.get(2).get(0));
		ventanasSeccion2.get(2).get(1).setBounds(155, 389, 38, 60);
		add(ventanasSeccion2.get(2).get(1));
		ventanasSeccion2.get(2).get(2).setBounds(210, 389, 38, 60);
		add(ventanasSeccion2.get(2).get(2));
		ventanasSeccion2.get(2).get(3).setBounds(265, 389, 38, 60);
		add(ventanasSeccion2.get(2).get(3));
		ventanasSeccion2.get(2).get(4).setBounds(315, 389, 38, 60);
		add(ventanasSeccion2.get(2).get(4));
	}

	/**
	 * Grafica las ventanas de la seccion3
	 */
	public void graficarSeccion3() {
		ventanasSeccion3.get(0).get(0).setBounds(105, -3, 38, 60);
		add(ventanasSeccion3.get(0).get(0));
		ventanasSeccion3.get(0).get(1).setBounds(155, -3, 38, 60);
		add(ventanasSeccion3.get(0).get(1));
		ventanasSeccion3.get(0).get(2).setBounds(210, -3, 38, 60);
		add(ventanasSeccion3.get(0).get(2));
		ventanasSeccion3.get(0).get(3).setBounds(265, -3, 38, 60);
		add(ventanasSeccion3.get(0).get(3));
		ventanasSeccion3.get(0).get(4).setBounds(315, -3, 38, 60);
		add(ventanasSeccion3.get(0).get(4));

		ventanasSeccion3.get(1).get(0).setBounds(105, 71, 38, 60);
		add(ventanasSeccion3.get(1).get(0));
		ventanasSeccion3.get(1).get(1).setBounds(155, 71, 38, 60);
		add(ventanasSeccion3.get(1).get(1));
		ventanasSeccion3.get(1).get(2).setBounds(210, 71, 38, 60);
		add(ventanasSeccion3.get(1).get(2));
		ventanasSeccion3.get(1).get(3).setBounds(265, 71, 38, 60);
		add(ventanasSeccion3.get(1).get(3));
		ventanasSeccion3.get(1).get(4).setBounds(315, 71, 38, 60);
		add(ventanasSeccion3.get(1).get(4));

		ventanasSeccion3.get(2).get(0).setBounds(105, 145, 38, 60);
		add(ventanasSeccion3.get(2).get(0));
		ventanasSeccion3.get(2).get(1).setBounds(155, 145, 38, 60);
		add(ventanasSeccion3.get(2).get(1));
		ventanasSeccion3.get(2).get(2).setBounds(210, 145, 38, 60);
		add(ventanasSeccion3.get(2).get(2));
		ventanasSeccion3.get(2).get(3).setBounds(265, 145, 38, 60);
		add(ventanasSeccion3.get(2).get(3));
		ventanasSeccion3.get(2).get(4).setBounds(315, 145, 38, 60);
		add(ventanasSeccion3.get(2).get(4));
	}

	/**
	 * Simula el movimiento de Ralph, A MODIFICAR
	 */
	public void movimientoRalph() {
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				if (der) {
					if (ralph.getX() < 300) {

						ralph.setLocation(ralph.getX() + 1, ralph.getY());
						if (ralph.getX() >= 300)
							der = false;

						ralph.repaint();
					}
				} else {
					if (ralph.getX() > 73) {
						ralph.setLocation(ralph.getX() - 1, ralph.getY());
						if (ralph.getX() <= 73)
							der = true;
						ralph.repaint();
					}
				}
			}
		};
		timer.schedule(task, 10);
	}

	public void pasajeDeNivel() {
		if (Juego.getGame().realizarPasajeDeNivel()) {
			getInstance = new GraficaJuego();
		}
	}

	/**
	 * Actualiza el estado de la gráfica
	 */
	public void actualizar() {
		getGrafica().actualizarFelix();
		getGrafica().repararVentana();
		getGrafica().setContadorPasajeDeSeccion(getGrafica().getContadorPasajeDeSeccion() - 1);
		if (getGrafica().getContadorPasajeDeSeccion() <= 0) {
			getGrafica().subirSeccion();
			getGrafica().setContadorPasajeDeSeccion(2000);
		}
		// getGrafica().movimientoRalph();
		getGrafica().pasajeSeccion();
		getGrafica().movimientoLadrillos();
		getGrafica().agregarLadrillos();
		getGrafica().sacarLadrillos();
		getGrafica().cont -= 1;
		if (getGrafica().cont <= 0) {
			getGrafica().graficarLadrillos();
			cont = 500;
		}
		getGrafica().pasajeDeNivel();
	}

	public int getIntermedio() {
		return intermedio;
	}

	public void setIntermedio(int intermedio) {
		this.intermedio = intermedio;
	}

}
