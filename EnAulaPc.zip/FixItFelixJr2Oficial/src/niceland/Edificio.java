package niceland;

import java.util.ArrayList;

import modelo.Juego;

public class Edificio {
	private Seccion secciones;
	private static double probabilidadSeccion = 0.0;
	private ArrayList<Seccion> seccionVector = new ArrayList<Seccion>();

	public static double getProbabilidadSeccion() {
		return probabilidadSeccion;
	}

	public static void setProbabilidadSeccion(double probabilidadSeccion) {
		Edificio.probabilidadSeccion = probabilidadSeccion;
	}

	public ArrayList<Seccion> getSeccionVector() {
		return seccionVector;
	}

	public void setSeccionVector(ArrayList<Seccion> seccionVector) {
		this.seccionVector = seccionVector;
	}

	/**
	 * RETORNA LA SECCION QUE SE PASA POR PAR�METRO
	 * 
	 * @param i
	 * @return
	 */
	public Seccion getSeccion() {
		return this.secciones;
	}

	/**
	 * Simula el pasaje de secci�n
	 */
	public void pasarDeSeccion() {
		int seccion = Juego.getGame().getSeccionEnum().getSeccionNum(Juego.getGame().getSeccionEnum());
		secciones = seccionVector.get(seccion);
	}

	/**
	 * CONFIGURA LAS SECCIONES CON LA PASADA POR PAR�METRO
	 * 
	 * @param secciones
	 */
	public void setSeccion(Seccion seccion) {
		this.secciones = seccion;
	}

	/**
	 * CONSTRUCTOR DEL EDIFICIO
	 */
	public Edificio() {
		System.out.println("Se crea el edificio");
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_INFERIOR, 3));
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_MEDIA, 2));
		seccionVector.add(new Seccion(EstadoSeccion.SECCION_SUPERIOR, 1));
		secciones = seccionVector.get(0);
		probabilidadSeccion = 0.0;
	}

	/**
	 * Crea una nueva secci�n
	 * 
	 * @param ES
	 */
	public void nuevaSeccion(EstadoSeccion ES) {
		if (Juego.getGame().getSeccion() == 0) {
			this.secciones = new Seccion(ES, 3);
		} else if (Juego.getGame().getSeccion() == 2) {
			this.secciones = new Seccion(ES, 2);
		} else
			this.secciones = new Seccion(ES, 1);
	}

}
