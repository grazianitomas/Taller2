package entidades;

import individuos.DireccionFelix;

public class Posicion {
	private int posX;
	private int posY;

	/**
	 * Constructor vacio de posicion
	 */
	public Posicion() {

	}

	/**
	 * Constructor de Posicion
	 * 
	 * @param X
	 * @param Y
	 */
	public Posicion(int X, int Y) {
		posX = X;
		posY = Y;
	}

	/**
	 * DEVUELVE LA POSICION EN X DEL OBJETO
	 * 
	 * @return
	 */
	public int getPosX() {
		return posX;
	}

	/**
	 * SETEA LA POSICION EN X DEL OBJETO
	 * 
	 * @param posX
	 */
	public void setPosX(int posX) {
		this.posX = posX;
	}

	/**
	 * DEVUELVE LA POSICION EN Y DEL OBJETO
	 * 
	 * @return
	 */
	public int getPosY() {
		return posY;
	}

	/**
	 * SETEA LA POSICION EN X DEL OBJETO
	 * 
	 * @param posY
	 */
	public void setPosY(int posY) {
		this.posY = posY;
	}

	/**
	 * Retorna si es válida la posición actual
	 * 
	 * @return
	 */
	public boolean esValida() {
		if (this.getPosX() < 3 && this.getPosX() >= 0) {
			if (this.getPosY() < 5 && this.getPosY() >= 0) {
				return true;
			}
			return false;
		} else
			return false;
	}

	/**
	 * Retorna la siguiente posici�n a la que se mover�a Felix
	 * 
	 * @param direc
	 * @return
	 */
	public Posicion getNextPos(DireccionFelix direc) {
		Posicion pos = new Posicion(this.posX, this.posY);
		switch (direc) {
		case ARRIBA: {
			// if (this.posX > 0)
			pos = new Posicion(this.getPosX() - 1, this.getPosY());
			break;
		}
		case ABAJO: {
			// if (this.posX < 2)
			pos = new Posicion(this.getPosX() + 1, this.getPosY());
			break;
		}
		case DERECHA: {
			// if (this.posY < 4)
			pos = new Posicion(this.getPosX(), this.getPosY() + 1);
			break;
		}
		case IZQUIERDA: {
			// if (this.posY > 0)
			pos = new Posicion(this.getPosX(), this.getPosY() - 1);
			break;
		}
		case QUIETO: {
			pos = new Posicion(this.getPosX(), this.getPosY());
			break;
		}
		}
		return pos;
	}

	/**
	 * Configura la posicion actual para que est� dentro de los par�metros
	 */
	public void validarPosicion() {
		if (getPosX() > 2)
			setPosX(2);
		if (getPosX() < 0)
			setPosX(0);
		if (getPosY() > 4)
			setPosY(4);
		if (getPosY() < 0)
			setPosY(0);
	}

	/**
	 * Compara la posicion del objeto actual con la del par�metro pasado P
	 * 
	 * @param P
	 * @return
	 */
	public boolean equals(Posicion P) {
		if ((this.getPosX() == P.getPosX()) && (this.getPosY() == P.getPosY())) {
			return true;
		} else
			return false;
	}

	/**
	 * Cambia la posicion a la siguiente
	 * 
	 * @param siguiente
	 */
	public void cambiarPosicion(Posicion siguiente) {
		if (siguiente.posX < 3 || siguiente.posX > -1)
			this.posX = siguiente.posX;
		if (siguiente.posY < 5 || siguiente.posX > -1)
			this.posY = siguiente.posY;
	}

	public void mover(DireccionFelix direc) {
		switch (direc) {
		case ABAJO:
			moverAbajo();
			break;
		case ARRIBA:
			moverArriba();
			break;
		case DERECHA:
			moverDerecha();
			break;
		case IZQUIERDA:
			moverIzquierda();
			break;
		case QUIETO:
			break;
		default:
			break;
		}
	}

	/**
	 * Mueve la posicion a la izquierda
	 */
	public void moverIzquierda() {
		if (this.posY > 0)
			this.posY -= 1;
	}

	/**
	 * Mueve la posicion a la derecha
	 */
	public void moverDerecha() {
		if (this.posY < 4)
			this.posY += 1;
	}

	/**
	 * Mueve la posicion hacia arriba
	 */
	public void moverArriba() {
		if (this.posX > 0)
			this.posX -= 1;
	}

	/**
	 * Mueve la posicion hacia abajo
	 */
	public void moverAbajo() {
		if (this.posX < 2)
			this.posX += 1;
	}

}
