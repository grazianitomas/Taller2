package entidades;

public class Maceta{

	private boolean hay = false;

	/**
	 * Constructor vacío
	 */
	public Maceta() {
		super();
		
	}
	
	
	
	/**
	 * Retorna si hay maceta
	 * @return
	 */
	public boolean getHay() {
		return this.hay;
	}
	
	/**
	 * Configura si hay maceta
	 * @param b
	 */
	public void setHay(boolean b) {
		this.hay = b;
	}

}
