package vistas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controladores.Juego;
import individuos.DireccionFelix;
import ventanas.OpenClose;
import ventanas.TipoVentana;
import ventanas.Ventana;

public class GraficaJuego extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ArrayList<JLabel> pasto = new ArrayList<JLabel>();
	private JLabel felix = new JLabel();
	private JLabel ladrillo = new JLabel();
	private JLabel pajaro = new JLabel();
	private JLabel ralph = new JLabel();
	private JLabel torta1 = new JLabel();
	private JLabel torta2 = new JLabel();
	private JLabel seccion1 = new JLabel();
	private JLabel seccion2 = new JLabel();
	private JLabel seccion3 = new JLabel();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion1 = new ArrayList<ArrayList<JLabel>>();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion2 = new ArrayList<ArrayList<JLabel>>();
	private ArrayList<ArrayList<JLabel>> ventanasSeccion3 = new ArrayList<ArrayList<JLabel>>();
	private CopyOnWriteArrayList<JLabel> movimientoRalph = new CopyOnWriteArrayList<JLabel>();
	private Timer timer = new Timer();

	TimerTask task = new TimerTask() {

		@Override
		public void run() {

		}
	};

	/**
	 * Constructor del juego. Setea los jlabels
	 */
	public GraficaJuego() {
		setVisible(false);
		setLayout(null);
		addKeyListener(new MiTecladoEnJuego());
		setBackground(Color.BLACK);
		this.buscarImagenes();
		int x = 0;
		for (JLabel J : pasto) {
			J.setBounds(x, 683, 24, 18);
			add(J);
			if (x == 72)
				x += 263;
			x += 24;
		}
		felix.setBounds(207, 650, 35, 51);
		add(felix);
		ladrillo.setBounds(150, 150, 20, 13);
		pajaro.setBounds(200, 400, 33, 22);
		ralph.setBounds(185, 389, 100, 66);
		add(ralph);
		torta1.setBounds(105, 145, 20, 21);
		add(torta1);
		torta2.setBounds(105, 225, 20, 21);
		add(torta2);
		graficarSeccion1();
		graficarSeccion2();
		graficarSeccion3();
		seccion1.setBounds(70, 452, 315, 249);
		add(seccion1);
		seccion2.setBounds(70, 203, 315, 249);
		add(seccion2);
		seccion3.setBounds(70, -102, 315, 306);
		add(seccion3);
		setVisible(true);
	}

	/**
	 * Busca todas las imagenes de los JLabels
	 */
	private void buscarImagenes() {
		felix.setIcon(new ImageIcon("Fixitfelixrecortado/felix/slice136_@.png"));
		ladrillo.setIcon(new ImageIcon("Fixitfelixrecortado/rocas/slice10_10.png"));
		pajaro.setIcon(new ImageIcon("Fixitfelixrecortado/pajaro/slice09_09.png"));
		ralph.setIcon(new ImageIcon("Fixitfelixrecortado/ralph/slice163_@.png"));
		seccion1.setIcon(new ImageIcon("Fixitfelixrecortado/edificio/edificio_150_seccion1.png"));
		seccion2.setIcon(new ImageIcon("Fixitfelixrecortado/edificio/edificio_150_seccion2.png"));
		seccion3.setIcon(new ImageIcon("Fixitfelixrecortado/edificio/edificio_150_seccion3.png"));
		torta1.setIcon(new ImageIcon("Fixitfelixrecortado/pastel/slice12_12.png"));
		torta2.setIcon(new ImageIcon("Fixitfelixrecortado/pastel/slice13_13.png"));
		for (int i = 0; i < 9; i++) {
			pasto.add(new JLabel());
			pasto.get(i).setIcon(new ImageIcon("Fixitfelixrecortado/pasto.png"));
		}
		graficasVentanasSeccion1();
		graficasVentanasSeccion2();
		graficasVentanasSeccion3();
	}

	/**
	 * Asigna la gr�fica de ventana correspondiente a cada ventana dependiendo de
	 * sus paneles rotos en la instancia de juego
	 */
	private void graficasVentanasSeccion1() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(0).getVentana(i, j);
				int cant = window.getCantRotos();
				if (i == 2 && j == 2) {
					switch (cant) {
					case 0:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/pb_paneles_sanos.png"));
						break;
					case 1:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/pb_panelesrotos_1.png"));
						break;
					case 2:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/pb_panelesrotos_2.png"));
						break;
					case 3:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/pb_panelesrotos_3.png"));
						break;
					case 4:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/pb_panelesrotos_4.png"));
						break;
					}
				} else if (i == 1 && j == 2) {
					switch (cant) {
					case 0:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_paneles_sanos.png"));
						break;
					case 1:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_1.png"));
						break;
					case 2:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_2.png"));
						break;
					case 3:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_3.png"));
						break;
					case 4:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_4.png"));
						break;
					case 5:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_5.png"));
						break;
					case 6:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_6.png"));
						break;
					case 7:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_7.png"));
						break;
					case 8:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_8.png"));
						break;
					case 9:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_9.png"));
						break;
					case 10:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_10.png"));
						break;
					case 11:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_11.png"));
						break;
					case 12:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_12.png"));
						break;
					case 13:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_13.png"));
						break;
					case 14:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_14.png"));
						break;
					case 15:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_15.png"));
						break;
					case 16:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/semicirculares/1ro_panelesrotos_16.png"));
						break;
					}
				} else {
					if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
						OpenClose estado = (OpenClose) window.getEstado();
						switch (estado) {
						case ABIERTA_AMBOS:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice106_@.png"));
							break;
						case ABIERTA_DERECHA:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice108_@.png"));
							break;
						case ABIERTA_IZQUIERDA:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice107_@.png"));
							break;
						case CERRADA:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice105_@.png"));
						default:
							break;
						}
					} else {
						switch (cant) {
						case 0:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice100_@.png"));
							break;
						case 1:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice24_24.png"));
							break;
						case 2:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice113_@.png"));
							break;
						case 3:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice104_@.png"));
							break;
						case 4:
							ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice103_@.png"));
							break;
						}
					}
				}
				ventanas[j] = ventana;

			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion1.add(fila);

		}
	}

	private void graficasVentanasSeccion2() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(1).getVentana(i, j);
				int cant = window.getCantRotos();

				if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
					switch (window.getEstado()) {
					case ABIERTA_AMBOS:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice106_@.png"));
						break;
					case ABIERTA_DERECHA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice108_@.png"));
						break;
					case ABIERTA_IZQUIERDA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice107_@.png"));
						break;
					case CERRADA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice105_@.png"));
					default:
						break;
					}
				} else {
					switch (cant) {
					case 0:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice100_@.png"));
						break;
					case 1:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice24_24.png"));
						break;
					case 2:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice113_@.png"));
						break;
					case 3:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice104_@.png"));
						break;
					case 4:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice103_@.png"));
						break;
					}
				}
				ventanas[j] = ventana;
			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion2.add(fila);
		}
	}

	private void graficasVentanasSeccion3() {
		JLabel ventana;
		JLabel[] ventanas;
		ArrayList<JLabel> fila = new ArrayList<JLabel>();
		Ventana window;
		for (int i = 0; i < 3; i++) {
			ventanas = new JLabel[5];
			for (int j = 0; j < 5; j++) {
				ventana = new JLabel();
				window = Juego.getGame().getNiceland().getSeccionVector().get(2).getVentana(i, j);
				int cant = window.getCantRotos();
				if (window.getTipo().equals(TipoVentana.DOS_HOJAS)) {
					switch (window.getEstado()) {
					case ABIERTA_AMBOS:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice106_@.png"));
						break;
					case ABIERTA_DERECHA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice108_@.png"));
						break;
					case ABIERTA_IZQUIERDA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice107_@.png"));
						break;
					case CERRADA:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice105_@.png"));
					default:
						break;
					}
				} else {
					switch (cant) {
					case 0:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice100_@.png"));
						break;
					case 1:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice24_24.png"));
						break;
					case 2:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice113_@.png"));
						break;
					case 3:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice104_@.png"));
						break;
					case 4:
						ventana.setIcon(new ImageIcon("Fixitfelixrecortado/ventanas_y_panel/slice103_@.png"));
						break;
					}
				}
				ventanas[j] = ventana;
			}
			fila = new ArrayList<JLabel>(
					Arrays.asList(ventanas[0], ventanas[1], ventanas[2], ventanas[3], ventanas[4]));
			ventanasSeccion3.add(fila);
		}
	}

	@Override
	public void paintComponent(Graphics g) {

		dibujar(g);
	}

	private void dibujar(Graphics g) {
		super.paintComponent(g);
	}

	/**
	 * Grafica el mover a felix a la izquierda
	 */
	public void moverIzq() {
		
	}

	/**
	 * Grafica el mover a la derecha
	 */
	public void moverDer() {

	}

	/**
	 * Grafica el mover a arriba
	 */
	public void moverUp() {

	}

	/**
	 * Grafica mover abajo
	 */
	public void moverAbajo() {

	}

	/**
	 * Grafica a Felix cuando quiere moverse a la puerta dependiendo de donde est�
	 * 
	 * @param direc
	 */
	public void moverAPuerta(DireccionFelix direc) {
		switch (direc) {
		case ABAJO:

			break;
		case DERECHA:

			break;
		case IZQUIERDA:

			break;
		default:
			break;
		}
	}

	/**
	 * Comienza el task de la gr�fica
	 */
	public void darMarcha() {
		timer.schedule(task, 10);
	}

	/**
	 * Maneja los eventos del teclado
	 * 
	 * @author Emilio
	 *
	 */
	public class MiTecladoEnJuego extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {

			switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				if (Juego.getGame().moverIzquierda()) {
					moverIzq();
					/**
					 * Por si se quiere mover a la puerta
					 */
					if (Juego.getGame().ubicacionFelix().getPosX() == 3
							&& Juego.getGame().ubicacionFelix().getPosY() == 2) {
						moverAPuerta(DireccionFelix.IZQUIERDA);
					}
					/**
					 * Por si quiere salir de la puerta
					 */
				} else {
				}
				;
				break;
			case KeyEvent.VK_RIGHT:
				if (Juego.getGame().moverDerecha()) {
					moverDer();
					/**
					 * Por si se quiere mover a la puerta
					 */
					if (Juego.getGame().ubicacionFelix().getPosX() == 1
							&& Juego.getGame().ubicacionFelix().getPosY() == 2) {
						moverAPuerta(DireccionFelix.DERECHA);
					}
					/**
					 * Por si quiere salir de la puerta
					 */
				}
				;
				break;
			case KeyEvent.VK_DOWN:
				if (Juego.getGame().moverAbajo()) {
					moverAbajo();

					/**
					 * Por si se quiere mover a la puerta
					 */
					if (Juego.getGame().ubicacionFelix().getPosX() == 2
							&& Juego.getGame().ubicacionFelix().getPosY() == 1) {
						moverAPuerta(DireccionFelix.ABAJO);
					}
				}
				;
				break;
			case KeyEvent.VK_UP:
				if (Juego.getGame().moverArriba()) {
					moverUp();
					/**
					 * Por si quiere salir de la puerta
					 */
				}
				;
				break;
			case KeyEvent.VK_SPACE:
				if (Juego.getGame().martillazo()) {

					if (Juego.getGame().pasarSeccion()) {

					}
				} else {

				}
				break;
			case KeyEvent.VK_ESCAPE:

				break;
			default:
				System.out.println("�sta tecla no la conozco");
				break;
			}
			super.keyPressed(e);
		}
	}

	/**
	 * Grafica las ventanas de la seccion1
	 */
	private void graficarSeccion1() {
		ventanasSeccion1.get(0).get(0).setBounds(105, 468, 38, 60);
		add(ventanasSeccion1.get(0).get(0));
		ventanasSeccion1.get(0).get(1).setBounds(155, 468, 38, 60);
		add(ventanasSeccion1.get(0).get(1));
		ventanasSeccion1.get(0).get(2).setBounds(210, 468, 38, 60);
		add(ventanasSeccion1.get(0).get(2));
		ventanasSeccion1.get(0).get(3).setBounds(265, 468, 38, 60);
		add(ventanasSeccion1.get(0).get(3));
		ventanasSeccion1.get(0).get(4).setBounds(315, 468, 38, 60);
		add(ventanasSeccion1.get(0).get(4));

		ventanasSeccion1.get(1).get(0).setBounds(105, 550, 38, 60);
		add(ventanasSeccion1.get(1).get(0));
		ventanasSeccion1.get(1).get(1).setBounds(155, 550, 38, 60);
		add(ventanasSeccion1.get(1).get(1));
		ventanasSeccion1.get(1).get(2).setBounds(199, 550, 61, 56);
		add(ventanasSeccion1.get(1).get(2));
		ventanasSeccion1.get(1).get(3).setBounds(265, 550, 38, 60);
		add(ventanasSeccion1.get(1).get(3));
		ventanasSeccion1.get(1).get(4).setBounds(315, 550, 38, 60);
		add(ventanasSeccion1.get(1).get(4));

		ventanasSeccion1.get(2).get(0).setBounds(105, 628, 38, 60);
		add(ventanasSeccion1.get(2).get(0));
		ventanasSeccion1.get(2).get(1).setBounds(155, 628, 38, 60);
		add(ventanasSeccion1.get(2).get(1));
		ventanasSeccion1.get(2).get(2).setBounds(199, 605, 61, 97);
		add(ventanasSeccion1.get(2).get(2));
		ventanasSeccion1.get(2).get(3).setBounds(265, 628, 38, 60);
		add(ventanasSeccion1.get(2).get(3));
		ventanasSeccion1.get(2).get(4).setBounds(315, 628, 38, 60);
		add(ventanasSeccion1.get(2).get(4));
	}

	/**
	 * Grafica las ventanas de la seccion2
	 */
	public void graficarSeccion2() {
		ventanasSeccion2.get(0).get(0).setBounds(105, 225, 38, 60);
		add(ventanasSeccion2.get(0).get(0));
		ventanasSeccion2.get(0).get(1).setBounds(155, 225, 38, 60);
		add(ventanasSeccion2.get(0).get(1));
		ventanasSeccion2.get(0).get(2).setBounds(210, 225, 38, 60);
		add(ventanasSeccion2.get(0).get(2));
		ventanasSeccion2.get(0).get(3).setBounds(265, 225, 38, 60);
		add(ventanasSeccion2.get(0).get(3));
		ventanasSeccion2.get(0).get(4).setBounds(315, 225, 38, 60);
		add(ventanasSeccion2.get(0).get(4));

		ventanasSeccion2.get(1).get(0).setBounds(105, 302, 38, 60);
		add(ventanasSeccion2.get(1).get(0));
		ventanasSeccion2.get(1).get(1).setBounds(155, 302, 38, 60);
		add(ventanasSeccion2.get(1).get(1));
		ventanasSeccion2.get(1).get(2).setBounds(210, 302, 38, 60);
		add(ventanasSeccion2.get(1).get(2));
		ventanasSeccion2.get(1).get(3).setBounds(265, 302, 38, 60);
		add(ventanasSeccion2.get(1).get(3));
		ventanasSeccion2.get(1).get(4).setBounds(315, 302, 38, 60);
		add(ventanasSeccion2.get(1).get(4));

		ventanasSeccion2.get(2).get(0).setBounds(105, 379, 38, 60);
		add(ventanasSeccion2.get(2).get(0));
		ventanasSeccion2.get(2).get(1).setBounds(155, 379, 38, 60);
		add(ventanasSeccion2.get(2).get(1));
		ventanasSeccion2.get(2).get(2).setBounds(210, 379, 38, 60);
		add(ventanasSeccion2.get(2).get(2));
		ventanasSeccion2.get(2).get(3).setBounds(265, 379, 38, 60);
		add(ventanasSeccion2.get(2).get(3));
		ventanasSeccion2.get(2).get(4).setBounds(315, 379, 38, 60);
		add(ventanasSeccion2.get(2).get(4));
	}

	/**
	 * Grafica las ventanas de la seccion3
	 */
	public void graficarSeccion3() {
		ventanasSeccion3.get(0).get(0).setBounds(105, -13, 38, 60);
		add(ventanasSeccion3.get(0).get(0));
		ventanasSeccion3.get(0).get(1).setBounds(155, -13, 38, 60);
		add(ventanasSeccion3.get(0).get(1));
		ventanasSeccion3.get(0).get(2).setBounds(210, -13, 38, 60);
		add(ventanasSeccion3.get(0).get(2));
		ventanasSeccion3.get(0).get(3).setBounds(265, -13, 38, 60);
		add(ventanasSeccion3.get(0).get(3));
		ventanasSeccion3.get(0).get(4).setBounds(315, -13, 38, 60);
		add(ventanasSeccion3.get(0).get(4));

		ventanasSeccion3.get(1).get(0).setBounds(105, 61, 38, 60);
		add(ventanasSeccion3.get(1).get(0));
		ventanasSeccion3.get(1).get(1).setBounds(155, 61, 38, 60);
		add(ventanasSeccion3.get(1).get(1));
		ventanasSeccion3.get(1).get(2).setBounds(210, 61, 38, 60);
		add(ventanasSeccion3.get(1).get(2));
		ventanasSeccion3.get(1).get(3).setBounds(265, 61, 38, 60);
		add(ventanasSeccion3.get(1).get(3));
		ventanasSeccion3.get(1).get(4).setBounds(315, 61, 38, 60);
		add(ventanasSeccion3.get(1).get(4));

		ventanasSeccion3.get(2).get(0).setBounds(105, 135, 38, 60);
		add(ventanasSeccion3.get(2).get(0));
		ventanasSeccion3.get(2).get(1).setBounds(155, 135, 38, 60);
		add(ventanasSeccion3.get(2).get(1));
		ventanasSeccion3.get(2).get(2).setBounds(210, 135, 38, 60);
		add(ventanasSeccion3.get(2).get(2));
		ventanasSeccion3.get(2).get(3).setBounds(265, 135, 38, 60);
		add(ventanasSeccion3.get(2).get(3));
		ventanasSeccion3.get(2).get(4).setBounds(315, 135, 38, 60);
		add(ventanasSeccion3.get(2).get(4));
	}

}
