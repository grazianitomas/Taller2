package vistas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.concurrent.CopyOnWriteArrayList;
import java.io.*;
import javax.imageio.ImageIO;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class GraficaJuego extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private BufferedImage felix;
	private BufferedImage ladrillo;
	private BufferedImage pajaro;
	private BufferedImage ralph;
	private BufferedImage ventana;
	private BufferedImage panelSano;
	private BufferedImage panelRoto;
	private BufferedImage panelSemiRoto;
	private BufferedImage puerta;
	private BufferedImage semiCircular;
	private BufferedImage torta;
	private BufferedImage nube;// dejar
	private BufferedImage seccion1;// dejar
	private BufferedImage seccion2;// dejar
	private BufferedImage seccion3;// dejar
	private BufferedImage edificio;// dejar
	private CopyOnWriteArrayList<BufferedImage> movimientoRalph = new CopyOnWriteArrayList<BufferedImage>();

	public GraficaJuego() {
		setSize(480, 740);
		setLayout(null);
		this.buscarImagenes();
		setBackground(Color.BLACK);
		setVisible(true);
	}

	private void buscarImagenes() {
		try {
			felix = ImageIO.read(getClass().getClassLoader().getResourceAsStream("felix/slice135_@.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			ladrillo = ImageIO.read(getClass().getClassLoader().getResourceAsStream("rocas/slice10_10.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			pajaro = ImageIO.read(getClass().getClassLoader().getResourceAsStream("pajaro/slice09_09.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			ralph = ImageIO.read(getClass().getClassLoader().getResourceAsStream("ralph/slice163_@.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			ventana = ImageIO.read(getClass().getClassLoader().getResourceAsStream("ventanas_y_panel/slice102_@.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			panelSano = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("ventanas_y_panel/slice02_02.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			panelSemiRoto = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("ventanas_y_panel/slice04_04.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			puerta = ImageIO.read(getClass().getClassLoader().getResourceAsStream("semicirculares/slice42_42.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			semiCircular = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("semicirculares/slice605_@.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			torta = ImageIO.read(getClass().getClassLoader().getResourceAsStream("pastel/slice12_12.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			seccion1 = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("edificio/edificio_150_seccion1.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			seccion2 = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("edificio/edificio_150_seccion2.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			seccion3 = ImageIO
					.read(getClass().getClassLoader().getResourceAsStream("edificio/edificio_150_seccion3.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			edificio = ImageIO.read(getClass().getClassLoader().getResourceAsStream("edificio/edificio_150.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void paintComponent(Graphics g) {

		dibujar(g);
	}

	private void dibujar(Graphics g) {
		super.paintComponent(g);
		g.drawImage(edificio, 100, 100, null);
		g.drawImage(felix, 50, 70, null);
		g.drawImage(ralph, 30, 80, null);
		g.drawImage(seccion1, 60, 90, null);
		g.drawImage(seccion2, 20, 50, null);
		g.drawImage(seccion3, 40, 50, null);
		g.drawImage(torta, 10, 95, null);
		g.drawImage(semiCircular, 70, 20, null);
		g.drawImage(ladrillo, 60, 20, null);
		g.drawImage(ventana, 90, 10, null);
		g.drawImage(panelSano, 70, 20, null);
		g.drawImage(panelRoto, 45, 15, null);
		g.drawImage(panelSemiRoto, 50, 30, null);
		g.drawImage(puerta, 20, 80, null);
		g.drawImage(pajaro, 15, 76, null);
	}
}
