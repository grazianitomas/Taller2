package vistas;

import javax.swing.JFrame;

public class JuegoFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Menu menu = new Menu();
	private Top5 top5 = new Top5();
	private GraficaJuego juego = new GraficaJuego();

	private static JuegoFrame getInstance = new JuegoFrame();

	public static JuegoFrame getInstancia() {
		return getInstance;
	}

	public JuegoFrame() {
		setSize(480, 740);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setContentPane(juego);
		setResizable(false);
		setVisible(true);
	}
	
	public static void main(String[] args) {

	}
	
}
