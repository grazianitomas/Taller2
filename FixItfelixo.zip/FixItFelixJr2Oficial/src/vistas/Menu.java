
package vistas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import adapters.MiMouseJugar;
import adapters.MiMouseTop;
import controladores.Juego;;

public class Menu extends JPanel {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	private JLabel jugar = new JLabel("�JUGAR!");
	private JLabel top5 = new JLabel("�TOP 5!");
	private JComboBox<String> selecNivel = new JComboBox<String>();
	private BufferedImage ladrillo;
	private BufferedImage ladrillo2;
	private BufferedImage menu;
	private BufferedImage opciones;
	private String nivel;
	private CopyOnWriteArrayList<JLabel> imagenes = new CopyOnWriteArrayList<JLabel>();
	private Juego juego = Juego.getGame();

	public Menu() {
		setSize(480, 740);
		setLayout(null);
		this.buscarImagenes();
		jugar.setBounds(32, 650, 80, 40);
		jugar.addMouseListener(new MiMouseJugar());
		top5.setBounds(390, 650, 80, 40);
		top5.addMouseListener(new MiMouseTop());
		selecNivel.setBounds(390, 5, 75, 20);
		for (int i = 0; i < 10; i++)
			selecNivel.addItem("Nivel " + (i + 1));
		selecNivel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				nivel = selecNivel.getSelectedItem().toString();
				super.mouseClicked(e);
			}
		});
		selecNivel.setForeground(Color.RED);
		selecNivel.setBackground(Color.getColor("TRANSLUCENT"));
		jugar.setForeground(Color.WHITE);
		top5.setForeground(Color.WHITE);
		add(jugar);
		add(top5);
		add(selecNivel);
		setVisible(true);
	}

	private void buscarImagenes() {
		try {
			menu = ImageIO.read(getClass().getClassLoader().getResourceAsStream("fixitfelix2.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			ladrillo = ImageIO.read(getClass().getClassLoader().getResourceAsStream("ladrillootromenu.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			ladrillo2 = ImageIO.read(getClass().getClassLoader().getResourceAsStream("ladrillootromenu.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			opciones = ImageIO.read(getClass().getClassLoader().getResourceAsStream("tuercas-png-4.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void dibujar(Graphics g) {
		super.paintComponent(g);
		g.drawImage(menu, 0, 0, null);
		g.drawImage(ladrillo, 15, 650, null);
		g.drawImage(ladrillo2, 370, 650, null);
		g.drawImage(opciones, 395, 5, null);
	}

	public void repaint() {

	}

	@Override
	public void paintComponent(Graphics g) {
		dibujar(g);
	}

	/**
	 * @return RETORNA EL JLABEL JUGAR
	 */
	public JLabel getJugar() {
		return jugar;
	}

	/**
	 * @param CONFIGURA EL JLABEL JUGAR
	 */
	public void setJugar(JLabel jugar) {
		this.jugar = jugar;
	}

	/**
	 * @return RETORNA EL JLABEL TOP5
	 */
	public JLabel getTop5() {
		return top5;
	}

	/**
	 * @param CONFIGURA EL LABEL TOP5
	 */
	public void setTop5(JLabel top5) {
		this.top5 = top5;
	}

}
