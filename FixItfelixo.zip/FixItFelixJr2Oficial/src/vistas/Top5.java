package vistas;

import javax.swing.*;

public class Top5 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
