package ventanas;

public class Puerta extends Ventana {

	/*
	 * CREA LA PUERTA CON LA PROBABILIDAD DE PANELES ROTOS PASADA POR PARáMETRO
	 */
	public Puerta(double proba) {
		super();
		this.tipo = TipoVentana.PUERTA;
		for (int i = 0; i < 4; i++)
			this.paneles.add(new Panel(proba));
	}

}
