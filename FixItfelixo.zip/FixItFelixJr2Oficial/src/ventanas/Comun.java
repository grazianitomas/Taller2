package ventanas;

import java.util.ArrayList;

import entidades.Maceta;
import entidades.Moldura;
import java.util.Random;

public class Comun extends Ventana {

	/*
	 * CONSTRUCTOR VACÃ�O
	 */
	public Comun() {
		super();
		this.tipo = TipoVentana.COMUN;
	}

	private Random rand = new Random();

	/*
	 * CONSTRUCTOR SIMPLE
	 */
	public Comun(Maceta maceta, Moldura moldura, ArrayList<Panel> paneles) {
		super(maceta, moldura, paneles);
		this.tipo = TipoVentana.COMUN;
	}

	/*
	 * CONSTRUCTOR QUE TIENE EN CUENTA LAS PROBABILIDADES DE ROTO
	 */
	public Comun(double proba) {
		super();
		this.tipo = TipoVentana.COMUN;
		setMaceta(new Maceta());
		setMoldura(new Moldura());
//		if ((rand.nextDouble() / proba) > 0.3) {
//			if ((rand.nextDouble() / proba) > 0.6)
//				getMoldura().setHay(true);
//			else
//				getMoldura().setHay(false);
//			getMaceta().setHay(true);
//		} else
//			getMaceta().setHay(false);
		getMoldura().setHay(false);
		getMaceta().setHay(false);
		this.paneles.add(new Panel(proba));
		this.paneles.add(new Panel(proba, true));
	}

	public void setTipo(TipoVentana tipo) {
		this.tipo = tipo;
	}

	public TipoVentana getTipo() {
		return tipo;
	}
}
