package ventanas;

import entidades.Maceta;
import entidades.Moldura;

public class Semicircular extends Ventana {

	/*
	 * CONSTRUCTOR QUE NO CONFIGURA PANELES
	 */
	public Semicircular() {
		super();
		this.tipo = TipoVentana.SEMICIRCULAR;
	}

	/*
	 * CONSTRUCTOR QUE CONFIGURA PANELES
	 */
	public Semicircular(double proba) {
		super(new Maceta(), new Moldura());
		getMaceta().setHay(false);
		getMoldura().setHay(false);
		this.tipo = TipoVentana.SEMICIRCULAR;
		for (int i = 0; i < 8; i++)
			this.paneles.add(new Panel(proba));
	}

}
