package ventanas;

public enum OpenClose {
	/**
	 * Estados en los que puede estar una ventada de dos hojas
	 */
	ABIERTA_IZQUIERDA, ABIERTA_DERECHA, CERRADA;
}
