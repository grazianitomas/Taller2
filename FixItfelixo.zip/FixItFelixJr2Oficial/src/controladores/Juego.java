package controladores;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;

import entidades.Posicion;
import individuos.DireccionFelix;
import individuos.FelixJr;
import individuos.Individuo;
import individuos.Ladrillo;
import individuos.Pajaro;
import individuos.Ralph;
import niceland.Edificio;
import niceland.EstadoSeccion;
import ventanas.Ventana;

public class Juego {

	private FelixJr felix;
	private Edificio niceland;
	private Nivel nivel;
	private int seccionActual;
	private EstadoSeccion seccionActualEnum;
	private CopyOnWriteArrayList<Ladrillo> ladrillos = new CopyOnWriteArrayList<Ladrillo>();
	private CopyOnWriteArrayList<Individuo> individuos = new CopyOnWriteArrayList<Individuo>();
	private CopyOnWriteArrayList<Pajaro> pajaros = new CopyOnWriteArrayList<Pajaro>();
	private static Juego game;

	public static Juego getGame() {
		if (game == null) {
			game = new Juego();
		}
		return game;
	}

	/**
	 * AGREGA UN LADRILLO A LA ARRAYLIST
	 * 
	 * @param L
	 */
	public void agregarLadrillo(Ladrillo L) {
		ladrillos.add(L);
	}

	public CopyOnWriteArrayList<Individuo> getIndividuos() {
		return individuos;
	}

	public Edificio getNiceland() {
		return this.niceland;
	}

	/**
	 * SE INSTANCIA EL JUEGO
	 */
	private Juego() {
		System.out.println("Se inicia el juego");
		nivel = new Nivel();
		seccionActual = 0;
		niceland = new Edificio();
		seccionActualEnum = niceland.getSeccionVector().get(0).getSeccionActual();
		individuos.add(new Pajaro());
		individuos.add(new Ralph());
		felix = new FelixJr(2, 2);
	}

	Timer timer = new Timer();

	TimerTask timerTask = new TimerTask() {

		@Override
		public void run() {
			actualizar();
			sacarPajaros();
			sacarLadrillos();
			verificarPasajeDeNivel();
		}
	};

	public void darMarcha() {
		game = new Juego();
		timer.schedule(timerTask, 10);
	}

	/**
	 * INSTANCIA LA SECCI�N ACTUAL
	 * 
	 * @param i
	 */
	public void setSeccion(int i) {
		this.seccionActual = i;

	}

	public void setIndividuo(Individuo I) {
		this.individuos.add(I);
	}

	// DEVUELVE LA SECCI�N ACTUAL
	/**
	 * 
	 * @return
	 */
	public int getSeccion() {
		return this.seccionActual;
	}

	/**
	 * Actualiza el estado de los objetos en cada instancia;
	 */
	private void actualizar() {
		for (Individuo I : getGame().individuos)
			I.actualizar();
	}

	/*
	 * Verifica si se puede pasar de nivel
	 */
	private void verificarPasajeDeNivel() {
		if (getGame().pasarSeccion()) {
			getGame().seccionActual++;
			getGame().seccionActualEnum = getGame().seccionActualEnum.pasarSeccion(getGame().seccionActualEnum);
			if (getGame().getSeccion() == 4) {
				getGame().nivel.pasarNivel();
				getGame().seccionActual = 0;
				getGame().niceland = new Edificio();
				getGame().niceland.pasarDeSeccion(getGame().seccionActualEnum);
				System.out.println("Congratulaciones! Pasaste al nivel "
						+ getGame().nivel.getNivelActual().getNivelesNum(getGame().nivel.getNivelActual()));

			} else {
				getGame().niceland.pasarDeSeccion(getGame().seccionActualEnum);
			}
		}
	}

	/**
	 * ORDENA A FELIX A MOVERSE A LA IZQUIERDA SI SE PUEDE
	 */
	public boolean chequearIzquierda() {
		return getGame().felix.mover(DireccionFelix.IZQUIERDA);

	}

	/**
	 * ORDENA A FELIX A MOVERSE A LA ARRIBA SI SE PUEDE
	 */
	public boolean chequearArriba() {
		return getGame().felix.mover(DireccionFelix.ARRIBA);
	}

	/**
	 * ORDENA A FELIX A MOVERSE A LA DERECHA SI SE PUEDE
	 */
	public boolean chequearDerecha() {
		return getGame().felix.mover(DireccionFelix.DERECHA);
	}

	/**
	 * ORDENA A FELIX A MOVERSE A LA ABAJO SI SE PUEDE
	 */
	public boolean chequearAbajo() {
		return getGame().felix.mover(DireccionFelix.ABAJO);
	}

	/**
	 * ORDENA A FELIX A DAR UN MARTILLAZO EN SU POSICI�N
	 */
	public boolean martillazo() {
		Ventana aReparar = getGame().getNiceland().getSeccionVector().get(getGame().getSeccion())
				.getVentana(getGame().ubicacionFelix().getPosX(), getGame().ubicacionFelix().getPosY());
		return getGame().felix.darMartillazo(aReparar);
	}

	/**
	 * VERIFICA LA COLISION ENTRE FELIX Y ALGO
	 * 
	 * @return
	 */
	public static boolean colisionar() {
		for (Individuo i : getGame().individuos) {
			if (i.colision(getGame().felix.getPosicion())) {
				if (getGame().felix.getVidas() > 0)
					getGame().felix = new FelixJr(2, 2);
				return true;
			}
		}
		return false;
	}

	/**
	 * RETORNA LA POSICI�N ACTUAL DE FELIX
	 * 
	 * @return
	 */
	public Posicion ubicacionFelix() {
		return getGame().felix.getPosicion();
	}

	/**
	 * ELIMINA LOS LADRILLOS QUE SALGAN DEL L�MITE
	 * 
	 * @param juegaso
	 */
	private void sacarLadrillos() {
		ArrayList<Ladrillo> temporal = new ArrayList<Ladrillo>();
		for (Ladrillo e : getGame().ladrillos) {
			if (e.getPosY() > 740) {
				temporal.add(e);
			}
		}
		getGame().ladrillos.removeAll(temporal);
	}

	/**
	 * ELIMINA LOS PAJAROS QUE SE SALGAN DEL JUEGO
	 */
	private void sacarPajaros() {
		ArrayList<Pajaro> temporal = new ArrayList<Pajaro>();
		for (Pajaro p : getGame().pajaros) {
			if ((p.getPosX() > 480) || p.getPosX() < 0) {
				temporal.add(p);
			}
		}
		getGame().pajaros.removeAll(temporal);

	}

	/**
	 * VERIFICA SI SE PUEDE PASAR DE NIVEL
	 * 
	 * @return VERDADERO SI SE PUEDE
	 */
	public boolean pasarSeccion() {
		ArrayList<ArrayList<Ventana>> ventanas;
		ventanas = getGame().niceland.getSeccionVector().get(getGame().getSeccion()).getMatrizVentanas();
		int fila = ventanas.size();
		int col;
		for (int i = 0; i < fila; i++) {
			col = ventanas.get(i).size();
			for (int j = 0; j < col; j++)
				if (!ventanas.get(i).get(j).getSana())
					return false;
		}
		return true;
	}

	/**
	 * IMPLEMENTAR GANAR, VA EN LA PARTE GR�FICA
	 */
	public void ganar() {

	}

	/**
	 * Mueve la posicion a la izquierda
	 */
	public void moverIzquierda() {
		getGame().felix.getPosicion().moverIzquierda();
	}

	/**
	 * Mueve la posicion a la derecha
	 */
	public void moverDerecha() {
		getGame().felix.getPosicion().moverDerecha();
	}

	/**
	 * Mueve la posicion hacia arriba
	 */
	public void moverArriba() {
		getGame().felix.getPosicion().moverArriba();
	}

	/**
	 * Mueve la posicion hacia abajo
	 */
	public void moverAbajo() {
		getGame().felix.getPosicion().moverAbajo();
	}
	
	/**
	 * Ordena a felix a cambiar la posicion a por la pasada
	 * @param pos
	 */
	public void cambiarPosicion(Posicion pos) {
		getGame().felix.getPosicion().cambiarPosicion(pos);
	}

}
