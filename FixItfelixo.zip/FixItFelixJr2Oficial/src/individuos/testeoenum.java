package individuos;

public enum testeoenum {

}
