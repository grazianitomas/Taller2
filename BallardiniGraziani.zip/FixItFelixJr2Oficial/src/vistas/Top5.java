package vistas;

import javax.swing.*;

public class Top5 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JLabel prueba = new JLabel();
	private JLabel prueba2 = new JLabel();

	public Top5() {
		setSize(480, 740);
		setLayout(null);
		this.buscarImagenes();
		add(prueba);
		add(prueba2);
		setVisible(true);
	}

	private void buscarImagenes() {
		prueba.setIcon(new ImageIcon("Fixitfelixrecortado/pasto.png"));
		prueba.setLocation(33, 0);
		prueba2.setIcon(new ImageIcon("Fixitfelixrecortado/edificio/seccion_150_seccion2.png"));
		prueba2.setLocation(33, 300);

	}

}
