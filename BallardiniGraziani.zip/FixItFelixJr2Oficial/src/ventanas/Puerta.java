package ventanas;

import entidades.Maceta;
import entidades.Moldura;

public class Puerta extends Ventana {

	/*
	 * CREA LA PUERTA CON LA PROBABILIDAD DE PANELES ROTOS PASADA POR PARáMETRO
	 */
	public Puerta(double proba) {
		super(new Maceta(), new Moldura());
		this.tipo = TipoVentana.PUERTA;
		getMaceta().setHay(false);
		getMoldura().setHay(false);
		for (int i = 0; i < 4; i++)
			this.paneles.add(new Panel(proba));
	}

}
