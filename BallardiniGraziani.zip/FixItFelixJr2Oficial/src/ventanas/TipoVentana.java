package ventanas;

public enum TipoVentana {
	DOS_HOJAS, COMUN, PUERTA, SEMICIRCULAR;
}
