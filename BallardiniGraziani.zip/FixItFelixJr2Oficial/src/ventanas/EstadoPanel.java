package ventanas;

public enum EstadoPanel {
	/*
	 * ESTADOS EN LOS QUE SE ENCUENTRA UN PANEL
	 */
	ROTO, SEMI_ROTO, SANO;
}
