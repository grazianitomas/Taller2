package controladores;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import vistas.FrameMenu;

public class MiMouseMenu extends MouseAdapter {

	public MiMouseMenu() {
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		FrameMenu.instancia().setCard("Menu");
		super.mouseClicked(e);
	}

}
