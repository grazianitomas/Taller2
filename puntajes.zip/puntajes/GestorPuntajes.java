package puntajes;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class GestorPuntajes {
    private static final String NOMBRE_ARCHIVO = "puntajes.txt";
    private static final int CANTIDAD_RANKING = 5;
    private List<Puntaje> puntajes;

    public GestorPuntajes() {
        puntajes = leerDesdeArchivo();
    }

    private List<Puntaje> leerDesdeArchivo() {
        List<Puntaje> recuperado = new ArrayList<>(CANTIDAD_RANKING);
        try {
            BufferedReader reader = new BufferedReader(new FileReader(NOMBRE_ARCHIVO));
            String linea;

            while ((linea = reader.readLine()) != null) {
                int separador = linea.indexOf('-');
                String nombre = linea.substring(0, separador);
                int puntaje = Integer.parseInt(linea.substring(separador) + 1);
                recuperado.add(new Puntaje(puntaje, nombre));
            }

        } catch (Exception ignored) {

        }

        return recuperado;
    }

    public void guardarPuntajes() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(NOMBRE_ARCHIVO));
            for (Puntaje p : puntajes) {
                String lineaGuardar = p.getNombre() + " - " + p.getPuntaje();
                writer.println(lineaGuardar);
            }
            writer.close();
        } catch (IOException ignored) {
        }
    }

    public void actualizarPuntajes(Puntaje puntaje) {
        puntajes.add(puntaje);
        puntajes.sort(Comparator.comparingInt(Puntaje::getPuntaje).reversed());
        puntajes = puntajes.subList(0, Math.min(CANTIDAD_RANKING, puntajes.size()));
    }
}
