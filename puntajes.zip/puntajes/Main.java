package puntajes;

public class Main {
    public static void main(String[] args) {
        GestorPuntajes gestorPuntajes = new GestorPuntajes();

        Puntaje p = new Puntaje(30, "Prueba1");
        Puntaje p2 = new Puntaje(50, "Prueba2");
        Puntaje p3 = new Puntaje(60, "Prueba3");
        Puntaje p4 = new Puntaje(90, "Prueba4");
        Puntaje p5 = new Puntaje(100, "Prueba5");
        Puntaje p6 = new Puntaje(110, "Prueba6");

        gestorPuntajes.actualizarPuntajes(p);
        gestorPuntajes.actualizarPuntajes(p2);
        gestorPuntajes.actualizarPuntajes(p3);
        gestorPuntajes.actualizarPuntajes(p4);
        gestorPuntajes.actualizarPuntajes(p5);
        gestorPuntajes.actualizarPuntajes(p6);

        gestorPuntajes.guardarPuntajes();
    }
}

