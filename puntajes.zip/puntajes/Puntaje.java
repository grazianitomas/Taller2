package puntajes;

class Puntaje {
    private int puntaje;
    private String nombre;

    Puntaje(int puntaje, String nombre) {
        this.puntaje = puntaje;
        this.nombre = nombre;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public String getNombre() {
        return nombre;
    }

}
